-- ReiTask V1 — Migration 0002
-- Contractor identity + security hardening
-- Apply after reitask_v1_0001_core.sql

begin;

-- ============================================================
-- 1. Contractor user membership
-- ============================================================

create type public.contractor_user_status as enum (
  'ACTIVE',
  'INACTIVE'
);

create table if not exists public.contractor_users (
  contractor_id uuid not null references public.contractors(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  status public.contractor_user_status not null default 'ACTIVE',
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (contractor_id, user_id)
);

create index if not exists idx_contractor_users_user
  on public.contractor_users(user_id);

create index if not exists idx_contractor_users_contractor_status
  on public.contractor_users(contractor_id, status);

-- ============================================================
-- 2. Project linkage on attachments
--    This gives attachment RLS a safe project boundary.
-- ============================================================

alter table public.attachments
  add column if not exists project_id uuid
  references public.projects(id) on delete cascade;

create index if not exists idx_attachments_project
  on public.attachments(project_id);

-- ============================================================
-- 3. Security helper functions
-- ============================================================

create or replace function public.is_property_owner(target_property_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.properties p
    where p.id = target_property_id
      and p.owner_user_id = auth.uid()
  );
$$;

create or replace function public.is_project_owner(target_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.projects p
    join public.properties pr on pr.id = p.property_id
    where p.id = target_project_id
      and pr.owner_user_id = auth.uid()
  );
$$;

create or replace function public.is_contractor_user(target_contractor_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.contractor_users cu
    join public.contractors c on c.id = cu.contractor_id
    join public.organization_members om
      on om.organization_id = c.organization_id
     and om.user_id = cu.user_id
    where cu.contractor_id = target_contractor_id
      and cu.user_id = auth.uid()
      and cu.status = 'ACTIVE'
      and om.status = 'ACTIVE'
      and om.role = 'CONTRACTOR'
  );
$$;

create or replace function public.is_contractor_assigned_to_project(
  target_project_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.project_contractors pc
    join public.contractor_users cu
      on cu.contractor_id = pc.contractor_id
    where pc.project_id = target_project_id
      and cu.user_id = auth.uid()
      and cu.status = 'ACTIVE'
  );
$$;

create or replace function public.is_contractor_assigned_to_work_order(
  target_work_order_id uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.work_orders wo
    join public.contractor_users cu
      on cu.contractor_id = wo.contractor_id
    where wo.id = target_work_order_id
      and cu.user_id = auth.uid()
      and cu.status = 'ACTIVE'
  );
$$;

create or replace function public.can_access_project(target_project_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.projects p
    where p.id = target_project_id
      and (
        public.is_org_admin_or_ops(p.organization_id)
        or public.is_project_owner(p.id)
        or public.is_contractor_assigned_to_project(p.id)
      )
  );
$$;

create or replace function public.can_access_work_order(target_work_order_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.work_orders wo
    where wo.id = target_work_order_id
      and (
        public.is_org_admin_or_ops(wo.organization_id)
        or public.is_project_owner(wo.project_id)
        or public.is_contractor_assigned_to_work_order(wo.id)
      )
  );
$$;

create or replace function public.can_access_property(target_property_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.properties p
    where p.id = target_property_id
      and (
        public.is_org_admin_or_ops(p.organization_id)
        or public.is_property_owner(p.id)
        or exists (
          select 1
          from public.projects pr
          where pr.property_id = p.id
            and public.is_contractor_assigned_to_project(pr.id)
        )
      )
  );
$$;

-- ============================================================
-- 4. Contractor membership integrity
-- ============================================================

create or replace function public.validate_contractor_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  contractor_org uuid;
begin
  select c.organization_id
    into contractor_org
  from public.contractors c
  where c.id = new.contractor_id;

  if contractor_org is null then
    raise exception 'Contractor does not exist';
  end if;

  if not exists (
    select 1
    from public.organization_members om
    where om.organization_id = contractor_org
      and om.user_id = new.user_id
      and om.status = 'ACTIVE'
      and om.role = 'CONTRACTOR'
  ) then
    raise exception
      'Contractor user must have an ACTIVE CONTRACTOR membership in the contractor organization';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_validate_contractor_user
  on public.contractor_users;

create trigger trg_validate_contractor_user
before insert or update on public.contractor_users
for each row execute function public.validate_contractor_user();

-- ============================================================
-- 5. Updated-at trigger for contractor_users
-- ============================================================

drop trigger if exists trg_contractor_users_updated_at
  on public.contractor_users;

create trigger trg_contractor_users_updated_at
before update on public.contractor_users
for each row execute function public.set_updated_at();

-- ============================================================
-- 6. Replace overly broad RLS policies
-- ============================================================

-- Users: members of the same organization can see member profiles.
drop policy if exists users_select_own on public.users;
drop policy if exists users_update_own on public.users;

create policy users_select_org_members
on public.users
for select
using (
  id = auth.uid()
  or exists (
    select 1
    from public.organization_members me
    join public.organization_members them
      on them.organization_id = me.organization_id
    where me.user_id = auth.uid()
      and me.status = 'ACTIVE'
      and them.user_id = users.id
      and them.status = 'ACTIVE'
  )
);

create policy users_update_own
on public.users
for update
using (id = auth.uid())
with check (id = auth.uid());

-- Properties
drop policy if exists properties_select on public.properties;

create policy properties_select
on public.properties
for select
using (public.can_access_property(id));

-- Projects
drop policy if exists projects_select on public.projects;

create policy projects_select
on public.projects
for select
using (public.can_access_project(id));

-- Inspections
drop policy if exists inspections_select on public.inspections;

create policy inspections_select
on public.inspections
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
);

-- Scope versions
drop policy if exists scope_versions_select on public.scope_versions;

create policy scope_versions_select
on public.scope_versions
for select
using (
  public.can_access_project(project_id)
);

-- Scope items
drop policy if exists scope_items_select on public.scope_items;

create policy scope_items_select
on public.scope_items
for select
using (
  exists (
    select 1
    from public.scope_versions sv
    where sv.id = scope_items.scope_version_id
      and public.can_access_project(sv.project_id)
  )
);

-- Budget items: contractors do not receive financial line-item access.
drop policy if exists budget_items_select on public.budget_items;

create policy budget_items_select
on public.budget_items
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
);

-- Contractors
drop policy if exists contractors_select on public.contractors;

create policy contractors_select
on public.contractors
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_contractor_user(id)
);

-- Contractor users
drop policy if exists contractor_users_select on public.contractor_users;
drop policy if exists contractor_users_manage on public.contractor_users;

create policy contractor_users_select
on public.contractor_users
for select
using (
  public.is_org_admin_or_ops(
    (select c.organization_id
     from public.contractors c
     where c.id = contractor_users.contractor_id)
  )
  or user_id = auth.uid()
);

create policy contractor_users_manage
on public.contractor_users
for all
using (
  public.is_org_admin_or_ops(
    (select c.organization_id
     from public.contractors c
     where c.id = contractor_users.contractor_id)
  )
)
with check (
  public.is_org_admin_or_ops(
    (select c.organization_id
     from public.contractors c
     where c.id = contractor_users.contractor_id)
  )
);

-- Project contractors
drop policy if exists project_contractors_select on public.project_contractors;

create policy project_contractors_select
on public.project_contractors
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
  or public.is_contractor_user(contractor_id)
);

-- Work orders
drop policy if exists work_orders_select on public.work_orders;

create policy work_orders_select
on public.work_orders
for select
using (public.can_access_work_order(id));

-- Work order scope items
drop policy if exists work_order_scope_items_select
  on public.work_order_scope_items;

create policy work_order_scope_items_select
on public.work_order_scope_items
for select
using (
  public.can_access_work_order(work_order_id)
);

-- Progress updates
drop policy if exists progress_updates_select on public.progress_updates;
drop policy if exists progress_updates_insert on public.progress_updates;
drop policy if exists progress_updates_update on public.progress_updates;

create policy progress_updates_select
on public.progress_updates
for select
using (public.can_access_work_order(work_order_id));

create policy progress_updates_insert
on public.progress_updates
for insert
with check (
  public.can_access_work_order(work_order_id)
  and (
    public.is_org_admin_or_ops(organization_id)
    or submitted_by = auth.uid()
       and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

create policy progress_updates_update
on public.progress_updates
for update
using (
  public.is_org_admin_or_ops(organization_id)
  or (
    submitted_by = auth.uid()
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
)
with check (
  public.is_org_admin_or_ops(organization_id)
  or (
    submitted_by = auth.uid()
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

-- Change orders
drop policy if exists change_orders_select on public.change_orders;
drop policy if exists change_orders_insert on public.change_orders;
drop policy if exists change_orders_update on public.change_orders;

create policy change_orders_select
on public.change_orders
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
  or (
    work_order_id is not null
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

create policy change_orders_insert
on public.change_orders
for insert
with check (
  public.is_org_admin_or_ops(organization_id)
  or (
    requested_by = auth.uid()
    and work_order_id is not null
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

create policy change_orders_update
on public.change_orders
for update
using (
  public.is_org_admin_or_ops(organization_id)
  or (
    requested_by = auth.uid()
    and work_order_id is not null
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
)
with check (
  public.is_org_admin_or_ops(organization_id)
  or (
    requested_by = auth.uid()
    and work_order_id is not null
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

-- QC
drop policy if exists qc_inspections_select on public.qc_inspections;

create policy qc_inspections_select
on public.qc_inspections
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
  or (
    work_order_id is not null
    and public.is_contractor_assigned_to_work_order(work_order_id)
  )
);

-- Punch list
drop policy if exists punch_items_select on public.punch_items;

create policy punch_items_select
on public.punch_items
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or public.is_project_owner(project_id)
  or (
    assigned_contractor_id is not null
    and public.is_contractor_user(assigned_contractor_id)
  )
);

-- Attachments
drop policy if exists attachments_select on public.attachments;

create policy attachments_select
on public.attachments
for select
using (
  public.is_org_admin_or_ops(organization_id)
  or (
    project_id is not null
    and public.can_access_project(project_id)
  )
);

-- Audit logs: clients must not be able to forge audit history.
drop policy if exists audit_logs_insert on public.audit_logs;

-- Service-role/server-side code should write audit events.
-- No INSERT policy is intentionally created here.

-- ============================================================
-- 7. Keep notification visibility private
-- ============================================================

drop policy if exists notifications_select on public.notifications;

create policy notifications_select
on public.notifications
for select
using (user_id = auth.uid());

drop policy if exists notifications_update on public.notifications;

create policy notifications_update
on public.notifications
for update
using (user_id = auth.uid())
with check (user_id = auth.uid());

-- ============================================================
-- 8. Helpful indexes
-- ============================================================

create index if not exists idx_projects_property
  on public.projects(property_id);

create index if not exists idx_project_contractors_project_contractor
  on public.project_contractors(project_id, contractor_id);

create index if not exists idx_work_orders_project_contractor
  on public.work_orders(project_id, contractor_id);

create index if not exists idx_progress_updates_work_order
  on public.progress_updates(work_order_id);

create index if not exists idx_change_orders_project_work_order
  on public.change_orders(project_id, work_order_id);

create index if not exists idx_punch_items_project_contractor
  on public.punch_items(project_id, assigned_contractor_id);

commit;
