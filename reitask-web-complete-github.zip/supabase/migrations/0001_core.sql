-- ReiTask V1 — Supabase/PostgreSQL foundation
-- Migration 0001: core schema, constraints, indexes, triggers, and RLS
-- Apply to a fresh Supabase project.

begin;

create extension if not exists pgcrypto;

-- ============================================================
-- ENUMS
-- ============================================================

create type public.organization_status as enum (
  'ACTIVE', 'SUSPENDED', 'ARCHIVED'
);

create type public.membership_status as enum (
  'ACTIVE', 'INVITED', 'SUSPENDED', 'REMOVED'
);

create type public.user_role as enum (
  'ADMIN', 'OPERATIONS_MANAGER', 'CONTRACTOR', 'OWNER'
);

create type public.property_type as enum (
  'SINGLE_FAMILY', 'MULTI_FAMILY', 'CONDO',
  'TOWNHOUSE', 'COMMERCIAL', 'OTHER'
);

create type public.property_status as enum (
  'ACTIVE', 'INACTIVE', 'ARCHIVED'
);

create type public.project_status as enum (
  'PLANNING', 'INSPECTION', 'SCOPING', 'READY_FOR_WORK',
  'IN_PROGRESS', 'QC', 'PUNCH_LIST', 'COMPLETED',
  'ON_HOLD', 'CANCELLED'
);

create type public.inspection_status as enum (
  'DRAFT', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'
);

create type public.issue_severity as enum (
  'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
);

create type public.issue_status as enum (
  'OPEN', 'ADDRESSED', 'DEFERRED', 'CLOSED'
);

create type public.scope_version_status as enum (
  'DRAFT', 'SUBMITTED', 'APPROVED', 'SUPERSEDED', 'CANCELLED'
);

create type public.scope_priority as enum (
  'LOW', 'NORMAL', 'HIGH', 'CRITICAL'
);

create type public.scope_item_status as enum (
  'DRAFT', 'APPROVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'
);

create type public.budget_category as enum (
  'MATERIALS', 'LABOR', 'PERMITS', 'EQUIPMENT',
  'SUBCONTRACTOR', 'OTHER'
);

create type public.contractor_status as enum (
  'ACTIVE', 'INACTIVE', 'SUSPENDED', 'ARCHIVED'
);

create type public.assignment_status as enum (
  'ACTIVE', 'INACTIVE', 'COMPLETED', 'CANCELLED'
);

create type public.work_order_status as enum (
  'DRAFT', 'ASSIGNED', 'ACCEPTED', 'IN_PROGRESS',
  'SUBMITTED_FOR_REVIEW', 'QC', 'COMPLETED',
  'REJECTED', 'CANCELLED'
);

create type public.change_order_status as enum (
  'DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED', 'CANCELLED'
);

create type public.qc_status as enum (
  'PENDING', 'PASS', 'FAIL', 'REINSPECTION_REQUIRED'
);

create type public.qc_result as enum (
  'PASS', 'FAIL'
);

create type public.punch_priority as enum (
  'LOW', 'NORMAL', 'HIGH', 'CRITICAL'
);

create type public.punch_status as enum (
  'OPEN', 'IN_PROGRESS', 'SUBMITTED',
  'VERIFIED', 'REJECTED', 'CANCELLED'
);

create type public.notification_type as enum (
  'WORK_ORDER_ASSIGNED',
  'WORK_ORDER_ACCEPTED',
  'WORK_ORDER_DUE',
  'WORK_ORDER_OVERDUE',
  'PROGRESS_SUBMITTED',
  'CHANGE_ORDER_SUBMITTED',
  'CHANGE_ORDER_APPROVED',
  'CHANGE_ORDER_REJECTED',
  'QC_FAILED',
  'PUNCH_ITEM_ASSIGNED',
  'PUNCH_ITEM_SUBMITTED',
  'PUNCH_ITEM_REJECTED',
  'PROJECT_COMPLETED',
  'GENERAL'
);

-- ============================================================
-- COMMON TRIGGER
-- ============================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ============================================================
-- ORGANIZATION / USERS
-- ============================================================

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  status public.organization_status not null default 'ACTIVE',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint organizations_name_not_blank check (length(trim(name)) > 0),
  constraint organizations_slug_format
    check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$')
);

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organization_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.users(id) on delete cascade,
  role public.user_role not null,
  status public.membership_status not null default 'ACTIVE',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

-- ============================================================
-- PROPERTIES / PROJECTS
-- ============================================================

create table public.properties (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  owner_user_id uuid references public.users(id) on delete set null,
  name text not null,
  address_line_1 text not null,
  address_line_2 text,
  city text not null,
  state text not null,
  postal_code text,
  country text not null default 'US',
  property_type public.property_type not null,
  status public.property_status not null default 'ACTIVE',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint properties_name_not_blank check (length(trim(name)) > 0),
  constraint properties_address_not_blank check (length(trim(address_line_1)) > 0)
);

create table public.projects (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  property_id uuid not null references public.properties(id) on delete restrict,
  name text not null,
  description text,
  status public.project_status not null default 'PLANNING',
  start_date date,
  target_completion_date date,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint projects_name_not_blank check (length(trim(name)) > 0),
  constraint projects_date_order
    check (
      target_completion_date is null
      or start_date is null
      or target_completion_date >= start_date
    )
);

-- ============================================================
-- INSPECTIONS
-- ============================================================

create table public.inspections (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  inspector_user_id uuid references public.users(id) on delete set null,
  status public.inspection_status not null default 'DRAFT',
  inspection_date date not null default current_date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.inspection_areas (
  id uuid primary key default gen_random_uuid(),
  inspection_id uuid not null references public.inspections(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  constraint inspection_areas_name_not_blank check (length(trim(name)) > 0)
);

create table public.inspection_issues (
  id uuid primary key default gen_random_uuid(),
  inspection_area_id uuid not null references public.inspection_areas(id) on delete cascade,
  description text not null,
  severity public.issue_severity not null default 'MEDIUM',
  recommendation text,
  status public.issue_status not null default 'OPEN',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint inspection_issues_description_not_blank
    check (length(trim(description)) > 0)
);

-- ============================================================
-- SCOPE
-- ============================================================

create table public.scope_versions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  version_number integer not null,
  status public.scope_version_status not null default 'DRAFT',
  created_by uuid not null references public.users(id) on delete restrict,
  approved_by uuid references public.users(id) on delete restrict,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, version_number),
  constraint scope_versions_version_positive check (version_number > 0),
  constraint scope_versions_approval_consistency
    check (
      (status = 'APPROVED' and approved_by is not null and approved_at is not null)
      or status <> 'APPROVED'
    )
);

create table public.scope_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  scope_version_id uuid not null references public.scope_versions(id) on delete cascade,
  inspection_issue_id uuid references public.inspection_issues(id) on delete set null,
  category text not null,
  description text not null,
  quantity numeric(14,3) not null default 1,
  unit text not null default 'EA',
  labor_estimate numeric(14,2) not null default 0,
  material_estimate numeric(14,2) not null default 0,
  total_estimate numeric(14,2) generated always as
    (labor_estimate + material_estimate) stored,
  priority public.scope_priority not null default 'NORMAL',
  status public.scope_item_status not null default 'DRAFT',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint scope_items_description_not_blank check (length(trim(description)) > 0),
  constraint scope_items_category_not_blank check (length(trim(category)) > 0),
  constraint scope_items_unit_not_blank check (length(trim(unit)) > 0),
  constraint scope_items_quantity_nonnegative check (quantity >= 0),
  constraint scope_items_labor_nonnegative check (labor_estimate >= 0),
  constraint scope_items_material_nonnegative check (material_estimate >= 0)
);

-- ============================================================
-- BUDGET
-- ============================================================

create table public.budget_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  scope_item_id uuid references public.scope_items(id) on delete set null,
  category public.budget_category not null,
  description text not null,
  estimated_amount numeric(14,2) not null default 0,
  committed_amount numeric(14,2) not null default 0,
  actual_amount numeric(14,2) not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint budget_items_description_not_blank check (length(trim(description)) > 0),
  constraint budget_items_estimated_nonnegative check (estimated_amount >= 0),
  constraint budget_items_committed_nonnegative check (committed_amount >= 0),
  constraint budget_items_actual_nonnegative check (actual_amount >= 0)
);

-- ============================================================
-- CONTRACTORS
-- ============================================================

create table public.contractors (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  company_name text not null,
  contact_name text,
  email text,
  phone text,
  status public.contractor_status not null default 'ACTIVE',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint contractors_company_name_not_blank
    check (length(trim(company_name)) > 0)
);

create table public.trades (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now(),
  constraint trades_name_not_blank check (length(trim(name)) > 0)
);

create table public.contractor_trades (
  contractor_id uuid not null references public.contractors(id) on delete cascade,
  trade_id uuid not null references public.trades(id) on delete restrict,
  created_at timestamptz not null default now(),
  primary key (contractor_id, trade_id)
);

create table public.project_contractors (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  contractor_id uuid not null references public.contractors(id) on delete restrict,
  role text,
  status public.assignment_status not null default 'ACTIVE',
  assigned_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (project_id, contractor_id)
);

-- ============================================================
-- WORK ORDERS
-- ============================================================

create sequence public.work_order_number_seq;

create table public.work_orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  contractor_id uuid not null references public.contractors(id) on delete restrict,
  work_order_number text not null,
  title text not null,
  description text,
  trade_id uuid references public.trades(id) on delete set null,
  status public.work_order_status not null default 'DRAFT',
  scheduled_start date,
  due_date date,
  completed_at timestamptz,
  created_by uuid not null references public.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, work_order_number),
  constraint work_orders_title_not_blank check (length(trim(title)) > 0),
  constraint work_orders_date_order
    check (
      due_date is null
      or scheduled_start is null
      or due_date >= scheduled_start
    )
);

create or replace function public.assign_work_order_number()
returns trigger
language plpgsql
as $$
begin
  if new.work_order_number is null or trim(new.work_order_number) = '' then
    new.work_order_number :=
      'WO-' || lpad(nextval('public.work_order_number_seq')::text, 6, '0');
  end if;
  return new;
end;
$$;

create trigger trg_work_order_number
before insert on public.work_orders
for each row execute function public.assign_work_order_number();

create table public.work_order_scope_items (
  work_order_id uuid not null references public.work_orders(id) on delete cascade,
  scope_item_id uuid not null references public.scope_items(id) on delete restrict,
  quantity numeric(14,3) not null default 1,
  created_at timestamptz not null default now(),
  primary key (work_order_id, scope_item_id),
  constraint work_order_scope_quantity_nonnegative check (quantity >= 0)
);

-- ============================================================
-- EXECUTION / PROGRESS
-- ============================================================

create table public.progress_updates (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  work_order_id uuid not null references public.work_orders(id) on delete cascade,
  submitted_by uuid not null references public.users(id) on delete restrict,
  completion_percent integer not null,
  notes text,
  submitted_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  constraint progress_completion_range
    check (completion_percent between 0 and 100)
);

-- ============================================================
-- CHANGE ORDERS
-- ============================================================

create table public.change_orders (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  work_order_id uuid references public.work_orders(id) on delete set null,
  requested_by uuid not null references public.users(id) on delete restrict,
  description text not null,
  reason text,
  cost_impact numeric(14,2) not null default 0,
  schedule_impact_days integer not null default 0,
  status public.change_order_status not null default 'DRAFT',
  approved_by uuid references public.users(id) on delete restrict,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint change_orders_description_not_blank
    check (length(trim(description)) > 0),
  constraint change_orders_schedule_nonnegative check (schedule_impact_days >= 0),
  constraint change_orders_approval_consistency
    check (
      (status = 'APPROVED' and approved_by is not null and approved_at is not null)
      or status <> 'APPROVED'
    )
);

-- ============================================================
-- QC
-- ============================================================

create table public.qc_inspections (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  work_order_id uuid not null references public.work_orders(id) on delete restrict,
  inspector_user_id uuid not null references public.users(id) on delete restrict,
  status public.qc_status not null default 'PENDING',
  notes text,
  inspected_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qc_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  qc_inspection_id uuid not null references public.qc_inspections(id) on delete cascade,
  scope_item_id uuid references public.scope_items(id) on delete set null,
  description text not null,
  result public.qc_result,
  correction_required text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint qc_items_description_not_blank
    check (length(trim(description)) > 0)
);

-- ============================================================
-- PUNCH LIST
-- ============================================================

create table public.punch_items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  project_id uuid not null references public.projects(id) on delete restrict,
  work_order_id uuid references public.work_orders(id) on delete set null,
  assigned_contractor_id uuid references public.contractors(id) on delete set null,
  description text not null,
  location text,
  priority public.punch_priority not null default 'NORMAL',
  status public.punch_status not null default 'OPEN',
  due_date date,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint punch_items_description_not_blank
    check (length(trim(description)) > 0)
);

-- ============================================================
-- ATTACHMENTS
-- ============================================================

create table public.attachments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  uploaded_by uuid not null references public.users(id) on delete restrict,
  storage_path text not null,
  file_name text not null,
  mime_type text not null,
  file_size bigint,
  entity_type text not null,
  entity_id uuid not null,
  created_at timestamptz not null default now(),
  constraint attachments_path_not_blank check (length(trim(storage_path)) > 0),
  constraint attachments_file_name_not_blank check (length(trim(file_name)) > 0),
  constraint attachments_file_size_nonnegative
    check (file_size is null or file_size >= 0)
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  recipient_user_id uuid not null references public.users(id) on delete cascade,
  type public.notification_type not null,
  title text not null,
  message text not null,
  entity_type text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz not null default now(),
  constraint notifications_title_not_blank check (length(trim(title)) > 0),
  constraint notifications_message_not_blank check (length(trim(message)) > 0)
);

-- ============================================================
-- AUDIT LOG
-- ============================================================

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  actor_user_id uuid references public.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid not null,
  old_values jsonb,
  new_values jsonb,
  created_at timestamptz not null default now(),
  constraint audit_logs_action_not_blank check (length(trim(action)) > 0),
  constraint audit_logs_entity_type_not_blank
    check (length(trim(entity_type)) > 0)
);

-- ============================================================
-- UPDATED_AT TRIGGERS
-- ============================================================

create trigger trg_organizations_updated_at before update on public.organizations
for each row execute function public.set_updated_at();

create trigger trg_users_updated_at before update on public.users
for each row execute function public.set_updated_at();

create trigger trg_organization_members_updated_at before update on public.organization_members
for each row execute function public.set_updated_at();

create trigger trg_properties_updated_at before update on public.properties
for each row execute function public.set_updated_at();

create trigger trg_projects_updated_at before update on public.projects
for each row execute function public.set_updated_at();

create trigger trg_inspections_updated_at before update on public.inspections
for each row execute function public.set_updated_at();

create trigger trg_inspection_issues_updated_at before update on public.inspection_issues
for each row execute function public.set_updated_at();

create trigger trg_scope_versions_updated_at before update on public.scope_versions
for each row execute function public.set_updated_at();

create trigger trg_scope_items_updated_at before update on public.scope_items
for each row execute function public.set_updated_at();

create trigger trg_budget_items_updated_at before update on public.budget_items
for each row execute function public.set_updated_at();

create trigger trg_contractors_updated_at before update on public.contractors
for each row execute function public.set_updated_at();

create trigger trg_project_contractors_updated_at before update on public.project_contractors
for each row execute function public.set_updated_at();

create trigger trg_work_orders_updated_at before update on public.work_orders
for each row execute function public.set_updated_at();

create trigger trg_change_orders_updated_at before update on public.change_orders
for each row execute function public.set_updated_at();

create trigger trg_qc_inspections_updated_at before update on public.qc_inspections
for each row execute function public.set_updated_at();

create trigger trg_qc_items_updated_at before update on public.qc_items
for each row execute function public.set_updated_at();

create trigger trg_punch_items_updated_at before update on public.punch_items
for each row execute function public.set_updated_at();

-- ============================================================
-- INDEXES
-- ============================================================

create index idx_org_members_user on public.organization_members(user_id);
create index idx_org_members_org on public.organization_members(organization_id);

create index idx_properties_org on public.properties(organization_id);
create index idx_properties_owner on public.properties(owner_user_id);

create index idx_projects_org on public.projects(organization_id);
create index idx_projects_property on public.projects(property_id);
create index idx_projects_status on public.projects(status);

create index idx_inspections_org on public.inspections(organization_id);
create index idx_inspections_project on public.inspections(project_id);

create index idx_inspection_areas_inspection on public.inspection_areas(inspection_id);
create index idx_inspection_issues_area on public.inspection_issues(inspection_area_id);

create index idx_scope_versions_project on public.scope_versions(project_id);
create index idx_scope_items_version on public.scope_items(scope_version_id);
create index idx_scope_items_issue on public.scope_items(inspection_issue_id);

create index idx_budget_items_project on public.budget_items(project_id);
create index idx_budget_items_scope on public.budget_items(scope_item_id);

create index idx_contractors_org on public.contractors(organization_id);
create index idx_contractor_trades_trade on public.contractor_trades(trade_id);

create index idx_project_contractors_project on public.project_contractors(project_id);
create index idx_project_contractors_contractor on public.project_contractors(contractor_id);

create index idx_work_orders_project on public.work_orders(project_id);
create index idx_work_orders_contractor on public.work_orders(contractor_id);
create index idx_work_orders_status on public.work_orders(status);
create index idx_work_orders_due_date on public.work_orders(due_date);

create index idx_work_order_scope_scope on public.work_order_scope_items(scope_item_id);

create index idx_progress_work_order on public.progress_updates(work_order_id);

create index idx_change_orders_project on public.change_orders(project_id);
create index idx_change_orders_status on public.change_orders(status);

create index idx_qc_project on public.qc_inspections(project_id);
create index idx_qc_work_order on public.qc_inspections(work_order_id);
create index idx_qc_items_inspection on public.qc_items(qc_inspection_id);

create index idx_punch_project on public.punch_items(project_id);
create index idx_punch_status on public.punch_items(status);
create index idx_punch_contractor on public.punch_items(assigned_contractor_id);

create index idx_attachments_entity on public.attachments(entity_type, entity_id);
create index idx_attachments_org on public.attachments(organization_id);

create index idx_notifications_recipient on public.notifications(recipient_user_id);
create index idx_notifications_unread
  on public.notifications(recipient_user_id, created_at desc)
  where read_at is null;

create index idx_audit_entity on public.audit_logs(entity_type, entity_id);
create index idx_audit_org_created on public.audit_logs(organization_id, created_at desc);

-- ============================================================
-- RLS HELPER FUNCTIONS
-- ============================================================

create or replace function public.is_org_member(
  target_org uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members om
    where om.organization_id = target_org
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
  );
$$;

create or replace function public.has_org_role(
  target_org uuid,
  target_role public.user_role
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members om
    where om.organization_id = target_org
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role = target_role
  );
$$;

create or replace function public.is_org_admin_or_ops(
  target_org uuid
)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members om
    where om.organization_id = target_org
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role in ('ADMIN', 'OPERATIONS_MANAGER')
  );
$$;

-- ============================================================
-- ENABLE RLS
-- ============================================================

alter table public.organizations enable row level security;
alter table public.users enable row level security;
alter table public.organization_members enable row level security;
alter table public.properties enable row level security;
alter table public.projects enable row level security;
alter table public.inspections enable row level security;
alter table public.inspection_areas enable row level security;
alter table public.inspection_issues enable row level security;
alter table public.scope_versions enable row level security;
alter table public.scope_items enable row level security;
alter table public.budget_items enable row level security;
alter table public.contractors enable row level security;
alter table public.trades enable row level security;
alter table public.contractor_trades enable row level security;
alter table public.project_contractors enable row level security;
alter table public.work_orders enable row level security;
alter table public.work_order_scope_items enable row level security;
alter table public.progress_updates enable row level security;
alter table public.change_orders enable row level security;
alter table public.qc_inspections enable row level security;
alter table public.qc_items enable row level security;
alter table public.punch_items enable row level security;
alter table public.attachments enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

-- ============================================================
-- BASE RLS POLICIES
-- ============================================================

create policy organizations_select
on public.organizations for select
using (public.is_org_member(id));

create policy organizations_update
on public.organizations for update
using (public.has_org_role(id, 'ADMIN'))
with check (public.has_org_role(id, 'ADMIN'));

create policy users_select_self
on public.users for select
using (id = auth.uid());

create policy users_update_self
on public.users for update
using (id = auth.uid())
with check (id = auth.uid());

create policy organization_members_select
on public.organization_members for select
using (public.is_org_member(organization_id));

create policy organization_members_manage
on public.organization_members for all
using (public.has_org_role(organization_id, 'ADMIN'))
with check (public.has_org_role(organization_id, 'ADMIN'));

-- ============================================================
-- ORG-SCOPED OPERATIONAL POLICIES
-- ============================================================

create policy properties_select
on public.properties for select
using (public.is_org_member(organization_id));

create policy properties_manage
on public.properties for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy projects_select
on public.projects for select
using (public.is_org_member(organization_id));

create policy projects_manage
on public.projects for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy inspections_select
on public.inspections for select
using (public.is_org_member(organization_id));

create policy inspections_manage
on public.inspections for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy inspection_areas_select
on public.inspection_areas for select
using (
  exists (
    select 1
    from public.inspections i
    where i.id = inspection_id
      and public.is_org_member(i.organization_id)
  )
);

create policy inspection_areas_manage
on public.inspection_areas for all
using (
  exists (
    select 1
    from public.inspections i
    where i.id = inspection_id
      and public.is_org_admin_or_ops(i.organization_id)
  )
)
with check (
  exists (
    select 1
    from public.inspections i
    where i.id = inspection_id
      and public.is_org_admin_or_ops(i.organization_id)
  )
);

create policy inspection_issues_select
on public.inspection_issues for select
using (
  exists (
    select 1
    from public.inspection_areas ia
    join public.inspections i on i.id = ia.inspection_id
    where ia.id = inspection_area_id
      and public.is_org_member(i.organization_id)
  )
);

create policy inspection_issues_manage
on public.inspection_issues for all
using (
  exists (
    select 1
    from public.inspection_areas ia
    join public.inspections i on i.id = ia.inspection_id
    where ia.id = inspection_area_id
      and public.is_org_admin_or_ops(i.organization_id)
  )
)
with check (
  exists (
    select 1
    from public.inspection_areas ia
    join public.inspections i on i.id = ia.inspection_id
    where ia.id = inspection_area_id
      and public.is_org_admin_or_ops(i.organization_id)
  )
);

create policy scope_versions_select
on public.scope_versions for select
using (public.is_org_member(organization_id));

create policy scope_versions_manage
on public.scope_versions for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy scope_items_select
on public.scope_items for select
using (public.is_org_member(organization_id));

create policy scope_items_manage
on public.scope_items for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

-- Budget is intentionally restricted to admin/operations.
create policy budget_items_select
on public.budget_items for select
using (public.is_org_admin_or_ops(organization_id));

create policy budget_items_manage
on public.budget_items for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy contractors_select
on public.contractors for select
using (public.is_org_member(organization_id));

create policy contractors_manage
on public.contractors for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy trades_select
on public.trades for select
using (auth.uid() is not null);

create policy trades_manage
on public.trades for all
using (false)
with check (false);

create policy contractor_trades_select
on public.contractor_trades for select
using (
  exists (
    select 1 from public.contractors c
    where c.id = contractor_id
      and public.is_org_member(c.organization_id)
  )
);

create policy contractor_trades_manage
on public.contractor_trades for all
using (
  exists (
    select 1 from public.contractors c
    where c.id = contractor_id
      and public.is_org_admin_or_ops(c.organization_id)
  )
)
with check (
  exists (
    select 1 from public.contractors c
    where c.id = contractor_id
      and public.is_org_admin_or_ops(c.organization_id)
  )
);

create policy project_contractors_select
on public.project_contractors for select
using (public.is_org_member(organization_id));

create policy project_contractors_manage
on public.project_contractors for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy work_orders_select
on public.work_orders for select
using (
  public.is_org_admin_or_ops(organization_id)
  or exists (
    select 1
    from public.organization_members om
    where om.organization_id = work_orders.organization_id
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role = 'OWNER'
      and exists (
        select 1 from public.properties p
        join public.projects pr on pr.property_id = p.id
        where pr.id = work_orders.project_id
          and p.owner_user_id = auth.uid()
      )
  )
  or exists (
    select 1
    from public.organization_members om
    join public.contractors c on c.organization_id = om.organization_id
    where om.organization_id = work_orders.organization_id
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role = 'CONTRACTOR'
      and c.id = work_orders.contractor_id
  )
);

create policy work_orders_manage
on public.work_orders for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy work_order_scope_select
on public.work_order_scope_items for select
using (
  exists (
    select 1
    from public.work_orders wo
    where wo.id = work_order_id
      and (
        public.is_org_admin_or_ops(wo.organization_id)
        or exists (
          select 1
          from public.contractors c
          join public.organization_members om
            on om.organization_id = c.organization_id
          where c.id = wo.contractor_id
            and om.user_id = auth.uid()
            and om.status = 'ACTIVE'
            and om.role = 'CONTRACTOR'
        )
      )
  )
);

create policy work_order_scope_manage
on public.work_order_scope_items for all
using (
  exists (
    select 1 from public.work_orders wo
    where wo.id = work_order_id
      and public.is_org_admin_or_ops(wo.organization_id)
  )
)
with check (
  exists (
    select 1 from public.work_orders wo
    where wo.id = work_order_id
      and public.is_org_admin_or_ops(wo.organization_id)
  )
);

create policy progress_select
on public.progress_updates for select
using (
  public.is_org_member(organization_id)
);

create policy progress_insert
on public.progress_updates for insert
with check (
  public.is_org_member(organization_id)
  and (
    public.is_org_admin_or_ops(organization_id)
    or submitted_by = auth.uid()
  )
);

create policy progress_update
on public.progress_updates for update
using (
  public.is_org_admin_or_ops(organization_id)
  or submitted_by = auth.uid()
)
with check (
  public.is_org_admin_or_ops(organization_id)
  or submitted_by = auth.uid()
);

-- Change orders: contractors may create/update their own requests;
-- only operations/admin can approve/reject.
create policy change_orders_select
on public.change_orders for select
using (public.is_org_member(organization_id));

create policy change_orders_insert
on public.change_orders for insert
with check (
  public.is_org_admin_or_ops(organization_id)
  or requested_by = auth.uid()
);

create policy change_orders_update
on public.change_orders for update
using (
  public.is_org_admin_or_ops(organization_id)
  or (
    requested_by = auth.uid()
    and status in ('DRAFT', 'SUBMITTED')
  )
)
with check (
  public.is_org_admin_or_ops(organization_id)
  or requested_by = auth.uid()
);

create policy qc_select
on public.qc_inspections for select
using (public.is_org_member(organization_id));

create policy qc_manage
on public.qc_inspections for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy qc_items_select
on public.qc_items for select
using (public.is_org_member(organization_id));

create policy qc_items_manage
on public.qc_items for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy punch_select
on public.punch_items for select
using (public.is_org_member(organization_id));

create policy punch_manage
on public.punch_items for all
using (public.is_org_admin_or_ops(organization_id))
with check (public.is_org_admin_or_ops(organization_id));

create policy punch_contractor_update
on public.punch_items for update
using (
  exists (
    select 1
    from public.organization_members om
    join public.contractors c on c.organization_id = om.organization_id
    where c.id = assigned_contractor_id
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role = 'CONTRACTOR'
  )
)
with check (
  exists (
    select 1
    from public.organization_members om
    join public.contractors c on c.organization_id = om.organization_id
    where c.id = assigned_contractor_id
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
      and om.role = 'CONTRACTOR'
  )
);

-- ============================================================
-- ATTACHMENTS / NOTIFICATIONS / AUDIT
-- ============================================================

create policy attachments_select
on public.attachments for select
using (public.is_org_member(organization_id));

create policy attachments_insert
on public.attachments for insert
with check (
  public.is_org_member(organization_id)
  and uploaded_by = auth.uid()
);

create policy attachments_delete
on public.attachments for delete
using (
  uploaded_by = auth.uid()
  or public.is_org_admin_or_ops(organization_id)
);

create policy notifications_select
on public.notifications for select
using (
  recipient_user_id = auth.uid()
  and public.is_org_member(organization_id)
);

create policy notifications_update
on public.notifications for update
using (
  recipient_user_id = auth.uid()
)
with check (
  recipient_user_id = auth.uid()
);

create policy audit_logs_select
on public.audit_logs for select
using (public.has_org_role(organization_id, 'ADMIN'));

create policy audit_logs_insert
on public.audit_logs for insert
with check (
  public.is_org_member(organization_id)
);

create policy audit_logs_update
on public.audit_logs for update
using (false)
with check (false);

create policy audit_logs_delete
on public.audit_logs for delete
using (false);

-- ============================================================
-- PROJECT FINANCIAL SUMMARY
-- ============================================================

create view public.project_financial_summary
with (security_invoker = true)
as
select
  p.id as project_id,
  p.organization_id,
  coalesce(sum(bi.estimated_amount), 0)::numeric(14,2) as estimated_budget,
  coalesce(sum(bi.committed_amount), 0)::numeric(14,2) as committed_cost,
  coalesce(sum(bi.actual_amount), 0)::numeric(14,2) as actual_cost,
  coalesce((
    select sum(co.cost_impact)
    from public.change_orders co
    where co.project_id = p.id
      and co.status = 'APPROVED'
  ), 0)::numeric(14,2) as approved_change_orders,
  (
    coalesce(sum(bi.estimated_amount), 0)
    +
    coalesce((
      select sum(co.cost_impact)
      from public.change_orders co
      where co.project_id = p.id
        and co.status = 'APPROVED'
    ), 0)
  )::numeric(14,2) as current_budget,
  (
    coalesce(sum(bi.estimated_amount), 0)
    +
    coalesce((
      select sum(co.cost_impact)
      from public.change_orders co
      where co.project_id = p.id
        and co.status = 'APPROVED'
    ), 0)
    -
    coalesce(sum(bi.actual_amount), 0)
  )::numeric(14,2) as remaining_budget
from public.projects p
left join public.budget_items bi on bi.project_id = p.id
group by p.id, p.organization_id;

-- ============================================================
-- SEED TRADES
-- ============================================================

insert into public.trades (name) values
  ('General Contractor'),
  ('Plumbing'),
  ('Electrical'),
  ('HVAC'),
  ('Roofing'),
  ('Flooring'),
  ('Painting'),
  ('Carpentry'),
  ('Drywall'),
  ('Cabinetry'),
  ('Landscaping'),
  ('Cleaning')
on conflict (name) do nothing;

commit;
