-- ReiTask V1 — Migration 0003
-- Authentication profile provisioning + safe organization onboarding
-- Apply after reitask_v1_0002_contractor_security.sql

begin;

-- ============================================================
-- 1. Create public.users automatically for every Auth user
-- ============================================================

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (
    id,
    email,
    full_name,
    is_active
  )
  values (
    new.id,
    lower(coalesce(new.email, '')),
    nullif(
      coalesce(
        new.raw_user_meta_data ->> 'full_name',
        new.raw_user_meta_data ->> 'name'
      ),
      ''
    ),
    true
  )
  on conflict (id) do update
    set email = excluded.email,
        full_name = coalesce(public.users.full_name, excluded.full_name),
        updated_at = now();

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
after insert on auth.users
for each row
execute function public.handle_new_auth_user();

-- ============================================================
-- 2. Keep profile email synchronized with Auth
-- ============================================================

create or replace function public.handle_auth_user_updated()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.users
     set email = lower(coalesce(new.email, email)),
         full_name = coalesce(
           nullif(new.raw_user_meta_data ->> 'full_name', ''),
           nullif(new.raw_user_meta_data ->> 'name', ''),
           full_name
         ),
         updated_at = now()
   where id = new.id;

  return new;
end;
$$;

drop trigger if exists on_auth_user_updated on auth.users;

create trigger on_auth_user_updated
after update of email, raw_user_meta_data on auth.users
for each row
execute function public.handle_auth_user_updated();

-- ============================================================
-- 3. Protect identity fields in public.users
-- ============================================================

-- Application users should not be able to change their own
-- organization identity, role, active state, or auth-linked ID.
-- These columns are controlled by server-side/admin workflows.
--
-- V1 application code should use a server-side service role or
-- controlled security-definer functions for administrative changes.

comment on column public.users.id is
  'Must match auth.users.id. Managed by authentication provisioning.';

comment on column public.users.email is
  'Synchronized from auth.users.email.';

-- ============================================================
-- 4. Organization membership status indexes
-- ============================================================

create index if not exists idx_organization_members_user_status
  on public.organization_members(user_id, status);

create index if not exists idx_organization_members_org_status_role
  on public.organization_members(organization_id, status, role);

create index if not exists idx_users_email_lower
  on public.users(lower(email));

-- ============================================================
-- 5. Make organization membership the source of role truth
-- ============================================================

comment on table public.organization_members is
  'Authoritative V1 organization membership and role boundary.';

comment on column public.organization_members.role is
  'Authoritative organization role for RLS. Do not use client-controlled profile fields for authorization.';

-- ============================================================
-- 6. RLS hardening for organization membership
-- ============================================================

drop policy if exists organization_members_select on public.organization_members;

create policy organization_members_select
on public.organization_members
for select
using (
  user_id = auth.uid()
  or exists (
    select 1
    from public.organization_members me
    where me.organization_id = organization_members.organization_id
      and me.user_id = auth.uid()
      and me.status = 'ACTIVE'
  )
);

-- Membership changes remain administrative.
drop policy if exists organization_members_insert
  on public.organization_members;

drop policy if exists organization_members_update
  on public.organization_members;

drop policy if exists organization_members_delete
  on public.organization_members;

-- Intentionally no client-side INSERT/UPDATE/DELETE policies.
-- Membership administration will be performed through controlled
-- server-side workflows.

-- ============================================================
-- 7. RLS hardening for organizations
-- ============================================================

drop policy if exists organizations_select on public.organizations;
drop policy if exists organizations_update on public.organizations;

create policy organizations_select
on public.organizations
for select
using (
  public.is_org_member(id)
);

create policy organizations_update
on public.organizations
for update
using (
  public.has_org_role(id, 'ADMIN')
)
with check (
  public.has_org_role(id, 'ADMIN')
);

-- Organization creation is a server-side onboarding operation.
drop policy if exists organizations_insert on public.organizations;

-- ============================================================
-- 8. Prevent users from self-enabling themselves
-- ============================================================

drop policy if exists users_insert on public.users;

-- New profiles are created by the auth trigger.
-- No direct client INSERT policy is intentionally created.

-- ============================================================
-- 9. Explicit role/security documentation
-- ============================================================

comment on table public.users is
  'Application profile linked 1:1 to auth.users. Authentication identity lives in Supabase Auth.';

comment on table public.organization_members is
  'Authorization boundary. RLS should use this table rather than trusting client-provided role metadata.';

commit;
