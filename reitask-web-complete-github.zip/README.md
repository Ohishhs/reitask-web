# ReiTask

ReiTask is a web-first renovation/rehab operations management platform.

## Current V1 build

- Next.js App Router + TypeScript + Tailwind CSS
- Supabase Auth + PostgreSQL + Row-Level Security
- Property and Project management
- Inspections, Areas, Issues
- Versioned Scope and Scope Items
- Budget tracking
- Contractor directory and project assignments
- Work Orders and status workflow
- Progress updates
- Change Orders
- QC inspections and checklist items

## Database setup

Run the migrations in `supabase/migrations/` in order:

1. `0001_core.sql`
2. `0002_contractor_security.sql`
3. `0003_auth_provisioning.sql`

## Local development

1. Copy `.env.example` to `.env.local`.
2. Add your Supabase URL and anon key.
3. Install dependencies with `npm install`.
4. Start the app with `npm run dev`.

## GitHub / Vercel

Do not commit `.env.local` or any Supabase secrets. Configure environment variables in Vercel instead.

## V1 status

This is the current development build. Punch List, Completion, Notifications, Contractor Performance, and final production/security hardening remain before production release.
