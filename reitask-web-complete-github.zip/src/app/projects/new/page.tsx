import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function NewProjectPage({
  searchParams
}: {
  searchParams: Promise<{ property_id?: string }>;
}) {
  const { property_id } = await searchParams;
  const supabase = await createClient();

  const { data: properties } = await supabase
    .from("properties")
    .select("id, address_line1, city, state")
    .order("address_line1");

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href="/properties" className="text-sm text-[var(--muted)]">
          ← Properties
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          New project
        </h1>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Start a renovation project under a property.
        </p>
      </div>

      <div className="p-5 md:p-8">
        <form
          action="/api/projects"
          method="post"
          className="max-w-2xl space-y-6 rounded-xl border border-[var(--border)] bg-white p-6"
        >
          <div>
            <label htmlFor="property_id" className="mb-1.5 block text-sm font-medium">
              Property
            </label>
            <select
              id="property_id"
              name="property_id"
              required
              defaultValue={property_id || ""}
              className="w-full rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
            >
              <option value="" disabled>
                Select a property
              </option>
              {properties?.map((property) => (
                <option key={property.id} value={property.id}>
                  {property.address_line1} — {[property.city, property.state].filter(Boolean).join(", ")}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="name" className="mb-1.5 block text-sm font-medium">
              Project name
            </label>
            <input
              id="name"
              name="name"
              required
              placeholder="Full renovation"
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <DateField name="start_date" label="Start date" />
            <DateField
              name="target_completion_date"
              label="Target completion"
            />
          </div>

          <div>
            <label htmlFor="description" className="mb-1.5 block text-sm font-medium">
              Description
            </label>
            <textarea
              id="description"
              name="description"
              rows={4}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>

          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link
              href="/properties"
              className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium"
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
            >
              Create project
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}

function DateField({ name, label }: { name: string; label: string }) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-medium">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type="date"
        className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
      />
    </div>
  );
}
