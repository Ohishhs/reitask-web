import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function WorkOrdersPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: project }, { data: orders }] = await Promise.all([
    supabase.from("projects").select("id, name").eq("id", id).maybeSingle(),
    supabase
      .from("work_orders")
      .select("id, work_order_number, title, status, priority, scheduled_start, scheduled_end, contractor_id, contractors(company_name)")
      .eq("project_id", id)
      .order("created_at", { ascending: false })
  ]);

  if (!project) notFound();

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">← {project.name}</Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Work Orders</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Assign, schedule, execute, and review project work.
            </p>
          </div>
          <Link href={`/projects/${id}/work-orders/new`} className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">
            New work order
          </Link>
        </div>
      </header>

      <div className="p-5 md:p-8">
        <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">
          {orders?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {orders.map((order) => (
                <Link key={order.id} href={`/projects/${id}/work-orders/${order.id}`} className="block px-5 py-5 hover:bg-black/[0.02]">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <div className="font-semibold">{order.title}</div>
                      <div className="mt-1 text-xs text-[var(--muted)]">
                        {order.work_order_number} · {Array.isArray(order.contractors) ? order.contractors[0]?.company_name : order.contractors?.company_name || "Unassigned"}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">{order.priority}</span>
                      <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">{order.status}</span>
                    </div>
                  </div>
                  <div className="mt-3 text-xs text-[var(--muted)]">
                    {order.scheduled_start ? `Start: ${order.scheduled_start}` : "Not scheduled"}
                    {order.scheduled_end ? ` · End: ${order.scheduled_end}` : ""}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">No work orders yet.</div>
          )}
        </section>
      </div>
    </main>
  );
}
