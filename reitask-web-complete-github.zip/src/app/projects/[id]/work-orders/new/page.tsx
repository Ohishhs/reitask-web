import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function NewWorkOrderPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: project }, { data: contractors }, { data: scopeVersions }] = await Promise.all([
    supabase.from("projects").select("id, name").eq("id", id).maybeSingle(),
    supabase.from("project_contractors").select("contractor_id, contractors(id, company_name)").eq("project_id", id).eq("status", "ACTIVE"),
    supabase.from("scope_versions").select("id, version_number, title").eq("project_id", id).order("version_number", { ascending: false })
  ]);

  if (!project) notFound();

  const scopeVersion = scopeVersions?.[0];
  const { data: scopeItems } = scopeVersion
    ? await supabase.from("scope_items").select("id, title, trade, status").eq("scope_version_id", scopeVersion.id).order("sort_order")
    : { data: [] };

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}/work-orders`} className="text-sm text-[var(--muted)]">← Work Orders</Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">New work order</h1>
        <p className="mt-1 text-sm text-[var(--muted)]">{project.name}</p>
      </header>

      <div className="p-5 md:p-8">
        <form action="/api/work-orders" method="post" className="max-w-3xl space-y-5 rounded-xl border border-[var(--border)] bg-white p-6">
          <input type="hidden" name="project_id" value={id} />
          <div className="grid gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <label className="mb-1.5 block text-sm font-medium">Title</label>
              <input name="title" required placeholder="Complete bathroom plumbing" className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5" />
            </div>
            <div className="md:col-span-2">
              <label className="mb-1.5 block text-sm font-medium">Description</label>
              <textarea name="description" rows={4} className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5" />
            </div>
            <select name="contractor_id" required className="rounded-lg border border-[var(--border)] px-3 py-2.5">
              <option value="">Assign contractor</option>
              {contractors?.map((row) => {
                const c = Array.isArray(row.contractors) ? row.contractors[0] : row.contractors;
                return <option key={row.contractor_id} value={row.contractor_id}>{c?.company_name}</option>;
              })}
            </select>
            <select name="priority" defaultValue="MEDIUM" className="rounded-lg border border-[var(--border)] px-3 py-2.5">
              <option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>URGENT</option>
            </select>
            <input name="scheduled_start" type="datetime-local" className="rounded-lg border border-[var(--border)] px-3 py-2.5" />
            <input name="scheduled_end" type="datetime-local" className="rounded-lg border border-[var(--border)] px-3 py-2.5" />
          </div>

          <div className="border-t border-[var(--border)] pt-5">
            <label className="mb-1.5 block text-sm font-medium">Scope item (optional)</label>
            <select name="scope_item_id" className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5">
              <option value="">No scope item</option>
              {scopeItems?.map((item) => <option key={item.id} value={item.id}>{item.title}{item.trade ? ` · ${item.trade}` : ""}</option>)}
            </select>
            {scopeVersion && <p className="mt-2 text-xs text-[var(--muted)]">Using latest scope version {scopeVersion.version_number}.</p>}
          </div>

          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link href={`/projects/${id}/work-orders`} className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium">Cancel</Link>
            <button className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Create work order</button>
          </div>
        </form>
      </div>
    </main>
  );
}
