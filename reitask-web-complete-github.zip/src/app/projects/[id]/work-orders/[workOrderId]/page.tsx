import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const statuses = ["DRAFT","ASSIGNED","ACCEPTED","IN_PROGRESS","SUBMITTED_FOR_REVIEW","QC","COMPLETED","REJECTED","CANCELLED"];

export default async function WorkOrderDetail({
  params
}: {
  params: Promise<{ id: string; workOrderId: string }>;
}) {
  const { id, workOrderId } = await params;
  const supabase = await createClient();

  const [{ data: order }, { data: linkedScope }] = await Promise.all([
    supabase
      .from("work_orders")
      .select("id, project_id, work_order_number, title, description, status, priority, scheduled_start, scheduled_end, contractor_id, contractors(company_name)")
      .eq("id", workOrderId)
      .eq("project_id", id)
      .maybeSingle(),
    supabase
      .from("work_order_scope_items")
      .select("scope_item_id, scope_items(id, title, trade)")
      .eq("work_order_id", workOrderId)
  ]);

  if (!order) notFound();

  const contractor = Array.isArray(order.contractors) ? order.contractors[0] : order.contractors;

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}/work-orders`} className="text-sm text-[var(--muted)]">← Work Orders</Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs text-[var(--muted)]">{order.work_order_number}</div>
            <h1 className="mt-1 text-2xl font-semibold tracking-tight">{order.title}</h1>
          </div>
          <span className="rounded-full bg-black/5 px-3 py-1.5 text-xs">{order.status}</span>
        </div>
      </header>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[1.4fr_0.8fr]">
        <section className="space-y-6">
          <div className="rounded-xl border border-[var(--border)] bg-white p-5">
            <h2 className="font-semibold">Execution details</h2>
            <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-[var(--muted)]">{order.description || "No description."}</p>
            <div className="mt-5 grid gap-4 border-t border-[var(--border)] pt-5 sm:grid-cols-2">
              <div><div className="text-xs text-[var(--muted)]">Contractor</div><div className="mt-1 text-sm font-medium">{contractor?.company_name || "—"}</div></div>
              <div><div className="text-xs text-[var(--muted)]">Priority</div><div className="mt-1 text-sm font-medium">{order.priority}</div></div>
              <div><div className="text-xs text-[var(--muted)]">Scheduled start</div><div className="mt-1 text-sm">{order.scheduled_start || "—"}</div></div>
              <div><div className="text-xs text-[var(--muted)]">Scheduled end</div><div className="mt-1 text-sm">{order.scheduled_end || "—"}</div></div>
            </div>
          </div>

          <div className="rounded-xl border border-[var(--border)] bg-white">
            <div className="border-b border-[var(--border)] px-5 py-4"><h2 className="font-semibold">Scope items</h2></div>
            {linkedScope?.length ? (
              <div className="divide-y divide-[var(--border)]">
                {linkedScope.map((row) => {
                  const item = Array.isArray(row.scope_items) ? row.scope_items[0] : row.scope_items;
                  return <div key={row.scope_item_id} className="px-5 py-4"><div className="font-medium">{item?.title}</div><div className="mt-1 text-xs text-[var(--muted)]">{item?.trade || "No trade"}</div></div>;
                })}
              </div>
            ) : <div className="p-6 text-sm text-[var(--muted)]">No scope items linked.</div>}
          </div>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white p-5">
          <div className="flex items-center justify-between gap-3"><h2 className="font-semibold">Update status</h2><Link href={`/projects/${id}/work-orders/${workOrderId}/progress`} className="text-sm underline">Progress</Link></div>
          <form action="/api/work-orders/status" method="post" className="mt-4 space-y-3">
            <input type="hidden" name="project_id" value={id} />
            <input type="hidden" name="work_order_id" value={workOrderId} />
            <select name="status" defaultValue={order.status} className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5">
              {statuses.map((status) => <option key={status}>{status}</option>)}
            </select>
            <button className="w-full rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Save status</button>
          </form>
        </section>
      </div>
    </main>
  );
}
