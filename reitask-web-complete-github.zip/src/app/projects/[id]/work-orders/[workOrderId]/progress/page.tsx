import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ProgressPage({
  params
}: {
  params: Promise<{ id: string; workOrderId: string }>;
}) {
  const { id, workOrderId } = await params;
  const supabase = await createClient();

  const [{ data: order }, { data: updates }] = await Promise.all([
    supabase
      .from("work_orders")
      .select("id, project_id, work_order_number, title, status, contractor_id, contractors(company_name)")
      .eq("id", workOrderId)
      .eq("project_id", id)
      .maybeSingle(),
    supabase
      .from("progress_updates")
      .select("id, completion_percent, notes, submitted_at, submitted_by")
      .eq("work_order_id", workOrderId)
      .order("created_at", { ascending: false })
  ]);

  if (!order) notFound();

  const contractor = Array.isArray(order.contractors) ? order.contractors[0] : order.contractors;
  const latestPercent = updates?.[0]?.completion_percent ?? 0;

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}/work-orders/${workOrderId}`} className="text-sm text-[var(--muted)]">
          ← {order.work_order_number}
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Progress</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">{order.title} · {contractor?.company_name || "Unassigned"}</p>
          </div>
          <div className="rounded-xl border border-[var(--border)] bg-white px-4 py-3">
            <div className="text-xs text-[var(--muted)]">Latest completion</div>
            <div className="mt-1 text-xl font-semibold">{latestPercent}%</div>
          </div>
        </div>
      </header>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[0.8fr_1.4fr]">
        <section className="rounded-xl border border-[var(--border)] bg-white p-5">
          <h2 className="font-semibold">Submit progress</h2>
          <form action="/api/progress-updates" method="post" className="mt-5 space-y-4">
            <input type="hidden" name="project_id" value={id} />
            <input type="hidden" name="work_order_id" value={workOrderId} />
            <div>
              <label className="mb-1.5 block text-sm font-medium">Percent complete</label>
              <input name="percent_complete" type="number" min="0" max="100" step="1" required className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium">Update notes</label>
              <textarea name="notes" rows={5} className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5" placeholder="What was completed?" />
            </div>
            <button className="w-full rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Submit update</button>
          </form>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="font-semibold">Progress history</h2>
          </div>
          {updates?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {updates.map((update) => (
                <div key={update.id} className="px-5 py-5">
                  <div className="flex items-center justify-between gap-4">
                    <div className="font-semibold">{update.completion_percent}% complete</div>
                    <div className="text-xs text-[var(--muted)]">
                      {new Date(update.submitted_at).toLocaleString()}
                    </div>
                  </div>
                  {update.notes && <p className="mt-3 whitespace-pre-wrap text-sm leading-6">{update.notes}</p>}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">No progress updates yet.</div>
          )}
        </section>
      </div>
    </main>
  );
}
