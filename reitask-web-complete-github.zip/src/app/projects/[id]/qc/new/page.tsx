import Link from "next/link";
import {notFound} from "next/navigation";
import {createClient} from "@/lib/supabase/server";
export default async function NewQC({params}:{params:Promise<{id:string}>}) {
 const {id}=await params; const s=await createClient();
 const [{data:project},{data:orders}]=await Promise.all([s.from("projects").select("id,name").eq("id",id).maybeSingle(),s.from("work_orders").select("id,work_order_number,title,status").eq("project_id",id).in("status",["SUBMITTED_FOR_REVIEW","QC"]).order("created_at",{ascending:false})]);
 if(!project)notFound();
 return <main className="min-h-screen bg-[var(--background)]"><header className="border-b border-[var(--border)] bg-white px-5 py-5"><Link href={`/projects/${id}/qc`}>← Quality Control</Link><h1 className="mt-2 text-2xl font-semibold">New QC inspection</h1></header><div className="p-5 md:p-8"><form action="/api/qc-inspections" method="post" className="max-w-2xl space-y-5 rounded-xl border bg-white p-6"><input type="hidden" name="project_id" value={id}/><select name="work_order_id" required className="w-full rounded-lg border px-3 py-2.5"><option value="">Select work order</option>{orders?.map((w:any)=><option key={w.id} value={w.id}>{w.work_order_number} — {w.title}</option>)}</select><textarea name="notes" rows={5} placeholder="Inspection notes" className="w-full rounded-lg border px-3 py-2.5"/><button className="rounded-lg bg-black px-4 py-2.5 text-white">Start inspection</button></form></div></main>;
}