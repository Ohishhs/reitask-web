import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function QCPage({params}:{params:Promise<{id:string}>}) {
 const {id}=await params; const s=await createClient();
 const [{data:project},{data:inspections}]=await Promise.all([
  s.from("projects").select("id,name").eq("id",id).maybeSingle(),
  s.from("qc_inspections").select("id,work_order_id,status,notes,inspected_at,created_at,work_orders(work_order_number,title)").eq("project_id",id).order("created_at",{ascending:false})
 ]);
 if(!project) notFound();
 return <main className="min-h-screen bg-[var(--background)]"><header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8"><Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">← {project.name}</Link><div className="mt-2 flex justify-between gap-4"><div><h1 className="text-2xl font-semibold">Quality Control</h1><p className="mt-1 text-sm text-[var(--muted)]">Review submitted work before completion.</p></div><Link href={`/projects/${id}/qc/new`} className="rounded-lg bg-black px-4 py-2.5 text-sm text-white">New QC inspection</Link></div></header><div className="p-5 md:p-8"><section className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">{inspections?.length?<div className="divide-y divide-[var(--border)]">{inspections.map((q:any)=><Link key={q.id} href={`/projects/${id}/qc/${q.id}`} className="block px-5 py-5 hover:bg-black/[0.02]"><div className="flex justify-between gap-3"><div><b>{q.work_orders?.work_order_number||"Work order"}</b><div className="text-sm text-[var(--muted)]">{q.work_orders?.title}</div></div><span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">{q.status}</span></div></Link>)}</div>:<div className="p-8 text-center text-sm text-[var(--muted)]">No QC inspections yet.</div>}</section></div></main>;
}