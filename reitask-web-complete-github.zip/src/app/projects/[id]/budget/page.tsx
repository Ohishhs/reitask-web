import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const categories = [
  "MATERIALS",
  "LABOR",
  "PERMITS",
  "EQUIPMENT",
  "SUBCONTRACTOR",
  "OTHER"
];

export default async function BudgetPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project } = await supabase
    .from("projects")
    .select("id, name")
    .eq("id", id)
    .maybeSingle();

  if (!project) notFound();

  const [{ data: items }, { data: financial }] = await Promise.all([
    supabase
      .from("budget_items")
      .select(
        "id, category, description, estimated_amount, committed_amount, actual_amount, scope_item_id"
      )
      .eq("project_id", id)
      .order("created_at", { ascending: true }),
    supabase
      .from("project_financial_summary")
      .select(
        "estimated_budget, committed_cost, actual_cost, approved_change_orders, current_budget, remaining_budget"
      )
      .eq("project_id", id)
      .maybeSingle()
  ]);

  const summary = financial ?? {
    estimated_budget: 0,
    committed_cost: 0,
    actual_cost: 0,
    approved_change_orders: 0,
    current_budget: 0,
    remaining_budget: 0
  };

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">
          ← {project.name}
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Budget</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Track estimated, committed, approved changes, and actual project costs.
            </p>
          </div>
        </div>
      </header>

      <div className="space-y-6 p-5 md:p-8">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[
            ["Estimated", summary.estimated_budget],
            ["Committed", summary.committed_cost],
            ["Approved changes", summary.approved_change_orders],
            ["Current budget", summary.current_budget],
            ["Remaining", summary.remaining_budget]
          ].map(([label, value]) => (
            <div
              key={String(label)}
              className="rounded-xl border border-[var(--border)] bg-white p-5"
            >
              <div className="text-xs text-[var(--muted)]">{label}</div>
              <div className="mt-2 text-xl font-semibold">
                {Number(value ?? 0).toLocaleString()}
              </div>
            </div>
          ))}
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="font-semibold">Add budget item</h2>
            <p className="mt-1 text-xs text-[var(--muted)]">
              Budget items may optionally reference a scope item.
            </p>
          </div>
          <form action="/api/budget-items" method="post" className="grid gap-3 p-5 md:grid-cols-2">
            <input type="hidden" name="project_id" value={id} />
            <select
              name="category"
              required
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
              defaultValue="LABOR"
            >
              {categories.map((category) => (
                <option key={category}>{category}</option>
              ))}
            </select>
            <input
              name="description"
              required
              placeholder="e.g. Plumbing rough-in"
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
            <input
              name="estimated_amount"
              required
              type="number"
              min="0"
              step="0.01"
              placeholder="Estimated amount"
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
            <input
              name="committed_amount"
              type="number"
              min="0"
              step="0.01"
              placeholder="Committed amount"
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
            <input
              name="actual_amount"
              type="number"
              min="0"
              step="0.01"
              placeholder="Actual amount"
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
            <input
              name="scope_item_id"
              placeholder="Scope item ID (optional)"
              className="rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
            <button
              type="submit"
              className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white md:col-span-2"
            >
              Add budget item
            </button>
          </form>
        </section>

        <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="font-semibold">Budget items</h2>
          </div>
          {items?.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-sm">
                <thead className="bg-black/[0.02] text-left text-xs text-[var(--muted)]">
                  <tr>
                    <th className="px-5 py-3">Description</th>
                    <th className="px-5 py-3">Category</th>
                    <th className="px-5 py-3 text-right">Estimated</th>
                    <th className="px-5 py-3 text-right">Committed</th>
                    <th className="px-5 py-3 text-right">Actual</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {items.map((item) => (
                    <tr key={item.id}>
                      <td className="px-5 py-4 font-medium">{item.description}</td>
                      <td className="px-5 py-4 text-[var(--muted)]">{item.category}</td>
                      <td className="px-5 py-4 text-right">
                        {Number(item.estimated_amount).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-right">
                        {Number(item.committed_amount).toLocaleString()}
                      </td>
                      <td className="px-5 py-4 text-right">
                        {Number(item.actual_amount).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">
              No budget items yet.
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
