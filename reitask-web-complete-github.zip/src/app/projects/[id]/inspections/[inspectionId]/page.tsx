import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function InspectionPage({
  params
}: {
  params: Promise<{ id: string; inspectionId: string }>;
}) {
  const { id, inspectionId } = await params;
  const supabase = await createClient();

  const { data: inspection } = await supabase
    .from("inspections")
    .select("id, project_id, name, status, inspection_date, summary")
    .eq("id", inspectionId)
    .eq("project_id", id)
    .maybeSingle();

  if (!inspection) notFound();

  const { data: areas } = await supabase
    .from("inspection_areas")
    .select("id, name, status, notes, sort_order")
    .eq("inspection_id", inspectionId)
    .order("sort_order", { ascending: true });

  const areaIds = areas?.map((area) => area.id) ?? [];

  const { data: issues } = areaIds.length
    ? await supabase
        .from("inspection_issues")
        .select(
          "id, area_id, title, description, severity, status, trade, estimated_cost"
        )
        .in("area_id", areaIds)
        .order("created_at", { ascending: true })
    : { data: [] };

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">
          ← Project
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              {inspection.name}
            </h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              {inspection.inspection_date || "Date not set"}
            </p>
          </div>
          <span className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-medium">
            {inspection.status}
          </span>
        </div>
      </header>

      <div className="p-5 md:p-8">
        <div className="grid gap-6 lg:grid-cols-[1fr_1.8fr]">
          <section className="rounded-xl border border-[var(--border)] bg-white p-6">
            <h2 className="font-semibold">Inspection summary</h2>
            <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-[var(--muted)]">
              {inspection.summary || "No summary recorded."}
            </p>

            <div className="mt-8 border-t border-[var(--border)] pt-5">
              <h3 className="text-sm font-semibold">Add area</h3>
              <form action="/api/inspection-areas" method="post" className="mt-4 space-y-3">
                <input type="hidden" name="inspection_id" value={inspectionId} />
                <input
                  name="name"
                  required
                  placeholder="Kitchen, master bath, exterior..."
                  className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
                />
                <button
                  className="w-full rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
                  type="submit"
                >
                  Add area
                </button>
              </form>
            </div>
          </section>

          <section className="rounded-xl border border-[var(--border)] bg-white">
            <div className="border-b border-[var(--border)] px-6 py-5">
              <h2 className="font-semibold">Inspection areas & issues</h2>
              <p className="mt-1 text-xs text-[var(--muted)]">
                Break the property into areas and record specific issues.
              </p>
            </div>

            {areas?.length ? (
              <div className="divide-y divide-[var(--border)]">
                {areas.map((area) => {
                  const areaIssues =
                    issues?.filter((issue) => issue.area_id === area.id) ?? [];

                  return (
                    <div key={area.id} className="p-6">
                      <div className="flex items-center justify-between gap-4">
                        <div>
                          <h3 className="font-medium">{area.name}</h3>
                          <p className="mt-1 text-xs text-[var(--muted)]">
                            {areaIssues.length} issue
                            {areaIssues.length === 1 ? "" : "s"}
                          </p>
                        </div>
                        <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs font-medium">
                          {area.status}
                        </span>
                      </div>

                      {areaIssues.length ? (
                        <div className="mt-5 space-y-3">
                          {areaIssues.map((issue) => (
                            <div
                              key={issue.id}
                              className="rounded-lg border border-[var(--border)] p-4"
                            >
                              <div className="flex items-start justify-between gap-4">
                                <div>
                                  <div className="font-medium">{issue.title}</div>
                                  <p className="mt-1 text-sm text-[var(--muted)]">
                                    {issue.description || "No description"}
                                  </p>
                                </div>
                                <span className="rounded-full bg-black/5 px-2 py-1 text-xs">
                                  {issue.severity}
                                </span>
                              </div>
                              <div className="mt-3 flex flex-wrap gap-3 text-xs text-[var(--muted)]">
                                <span>{issue.status}</span>
                                {issue.trade && <span>{issue.trade}</span>}
                                {issue.estimated_cost != null && (
                                  <span>Est. {issue.estimated_cost}</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="mt-4 rounded-lg bg-black/[0.025] p-4 text-sm text-[var(--muted)]">
                          No issues recorded for this area.
                        </div>
                      )}

                      <form
                        action="/api/inspection-issues"
                        method="post"
                        className="mt-5 grid gap-3 rounded-lg bg-black/[0.025] p-4 md:grid-cols-2"
                      >
                        <input type="hidden" name="inspection_id" value={inspectionId} />
                        <input type="hidden" name="area_id" value={area.id} />
                        <input
                          name="title"
                          required
                          placeholder="Issue title"
                          className="rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
                        />
                        <select
                          name="severity"
                          defaultValue="MEDIUM"
                          className="rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
                        >
                          <option value="LOW">Low</option>
                          <option value="MEDIUM">Medium</option>
                          <option value="HIGH">High</option>
                          <option value="CRITICAL">Critical</option>
                        </select>
                        <textarea
                          name="description"
                          placeholder="Describe the condition and required attention."
                          rows={3}
                          className="rounded-lg border border-[var(--border)] bg-white px-3 py-2.5 md:col-span-2"
                        />
                        <input
                          name="trade"
                          placeholder="Trade (e.g. Plumbing)"
                          className="rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
                        />
                        <input
                          name="estimated_cost"
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="Estimated cost"
                          className="rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
                        />
                        <button
                          type="submit"
                          className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white md:col-span-2"
                        >
                          Add issue
                        </button>
                      </form>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-sm text-[var(--muted)]">
                Add inspection areas to begin documenting the property.
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
