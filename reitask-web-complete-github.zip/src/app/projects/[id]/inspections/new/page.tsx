import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function NewInspectionPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project } = await supabase
    .from("projects")
    .select("id, name, property_id")
    .eq("id", id)
    .maybeSingle();

  if (!project) notFound();

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">
          ← {project.name}
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          New inspection
        </h1>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Create an inspection for this renovation project.
        </p>
      </header>

      <div className="p-5 md:p-8">
        <form
          action="/api/inspections"
          method="post"
          className="max-w-2xl space-y-6 rounded-xl border border-[var(--border)] bg-white p-6"
        >
          <input type="hidden" name="project_id" value={id} />

          <div>
            <label htmlFor="name" className="mb-1.5 block text-sm font-medium">
              Inspection name
            </label>
            <input
              id="name"
              name="name"
              required
              placeholder="Initial property inspection"
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>

          <div>
            <label
              htmlFor="inspection_date"
              className="mb-1.5 block text-sm font-medium"
            >
              Inspection date
            </label>
            <input
              id="inspection_date"
              name="inspection_date"
              type="date"
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>

          <div>
            <label
              htmlFor="summary"
              className="mb-1.5 block text-sm font-medium"
            >
              Summary
            </label>
            <textarea
              id="summary"
              name="summary"
              rows={5}
              placeholder="Overall condition, major observations, and immediate concerns."
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>

          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link
              href={`/projects/${id}`}
              className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium"
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
            >
              Create inspection
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
