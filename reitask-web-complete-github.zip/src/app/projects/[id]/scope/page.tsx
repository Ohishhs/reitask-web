import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ScopePage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project } = await supabase
    .from("projects")
    .select("id, name, property_id")
    .eq("id", id)
    .maybeSingle();

  if (!project) notFound();

  const { data: versions } = await supabase
    .from("scope_versions")
    .select("id, version_number, status, title, notes, created_at")
    .eq("project_id", id)
    .order("version_number", { ascending: false });

  const current = versions?.[0] ?? null;

  const { data: items } = current
    ? await supabase
        .from("scope_items")
        .select(
          "id, title, description, category, trade, quantity, unit, estimated_cost, status, sort_order"
        )
        .eq("scope_version_id", current.id)
        .order("sort_order", { ascending: true })
    : { data: [] };

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">
          ← {project.name}
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Scope</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Convert inspection findings into actionable work items.
            </p>
          </div>
          <Link
            href={`/projects/${id}/scope/new`}
            className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
          >
            New scope version
          </Link>
        </div>
      </header>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[0.8fr_1.8fr]">
        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="font-semibold">Scope versions</h2>
            <p className="mt-1 text-xs text-[var(--muted)]">
              Versions preserve the scope history.
            </p>
          </div>
          {versions?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {versions.map((version) => (
                <Link
                  key={version.id}
                  href={`/projects/${id}/scope?version=${version.id}`}
                  className="block px-5 py-4 hover:bg-black/[0.02]"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-medium">Version {version.version_number}</span>
                    <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">
                      {version.status}
                    </span>
                  </div>
                  <div className="mt-1 text-sm text-[var(--muted)]">
                    {version.title || "Untitled scope"}
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-6 text-sm text-[var(--muted)]">
              No scope version has been created.
            </div>
          )}
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
            <div>
              <h2 className="font-semibold">
                {current ? `Version ${current.version_number}` : "Scope items"}
              </h2>
              <p className="mt-1 text-xs text-[var(--muted)]">
                {current?.title || "Create a scope version to add work."}
              </p>
            </div>
            {current && (
              <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">
                {current.status}
              </span>
            )}
          </div>

          {current ? (
            <>
              <div className="border-b border-[var(--border)] px-5 py-4">
                <form
                  action="/api/scope-items"
                  method="post"
                  className="grid gap-3 md:grid-cols-2"
                >
                  <input type="hidden" name="scope_version_id" value={current.id} />
                  <input
                    name="title"
                    required
                    placeholder="Scope item"
                    className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                  />
                  <input
                    name="trade"
                    placeholder="Trade"
                    className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                  />
                  <input
                    name="category"
                    placeholder="Category"
                    className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                  />
                  <input
                    name="description"
                    placeholder="Description"
                    className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      name="quantity"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="Qty"
                      className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                    />
                    <input
                      name="unit"
                      placeholder="Unit"
                      className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                    />
                  </div>
                  <input
                    name="estimated_cost"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Estimated cost"
                    className="rounded-lg border border-[var(--border)] px-3 py-2.5"
                  />
                  <button
                    type="submit"
                    className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white md:col-span-2"
                  >
                    Add scope item
                  </button>
                </form>
              </div>

              {items?.length ? (
                <div className="divide-y divide-[var(--border)]">
                  {items.map((item) => (
                    <div key={item.id} className="px-5 py-5">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="font-medium">{item.title}</div>
                          <div className="mt-1 text-sm text-[var(--muted)]">
                            {item.description || "No description"}
                          </div>
                        </div>
                        <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">
                          {item.status}
                        </span>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-4 text-xs text-[var(--muted)]">
                        {item.trade && <span>{item.trade}</span>}
                        {item.category && <span>{item.category}</span>}
                        {item.quantity != null && (
                          <span>
                            {item.quantity} {item.unit || ""}
                          </span>
                        )}
                        {item.estimated_cost != null && (
                          <span>Est. {item.estimated_cost}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-sm text-[var(--muted)]">
                  No scope items yet.
                </div>
              )}
            </>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">
              Start by creating the first scope version.
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
