import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function NewScopeVersionPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project } = await supabase
    .from("projects")
    .select("id, name")
    .eq("id", id)
    .maybeSingle();

  if (!project) notFound();

  const { data: latest } = await supabase
    .from("scope_versions")
    .select("version_number")
    .eq("project_id", id)
    .order("version_number", { ascending: false })
    .limit(1)
    .maybeSingle();

  const nextVersion = (latest?.version_number ?? 0) + 1;

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href={`/projects/${id}/scope`} className="text-sm text-[var(--muted)]">
          ← Scope
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          New scope version
        </h1>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Create version {nextVersion} for {project.name}.
        </p>
      </header>

      <div className="p-5 md:p-8">
        <form
          action="/api/scope-versions"
          method="post"
          className="max-w-2xl space-y-6 rounded-xl border border-[var(--border)] bg-white p-6"
        >
          <input type="hidden" name="project_id" value={id} />
          <div>
            <label htmlFor="title" className="mb-1.5 block text-sm font-medium">
              Scope title
            </label>
            <input
              id="title"
              name="title"
              required
              placeholder="Renovation scope — initial"
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>
          <div>
            <label htmlFor="notes" className="mb-1.5 block text-sm font-medium">
              Notes
            </label>
            <textarea
              id="notes"
              name="notes"
              rows={5}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>
          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link
              href={`/projects/${id}/scope`}
              className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium"
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
            >
              Create draft
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
