import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ProjectPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: project } = await supabase
    .from("projects")
    .select(
      "id, property_id, name, description, status, start_date, target_completion_date"
    )
    .eq("id", id)
    .maybeSingle();

  if (!project) notFound();

  const { data: property } = await supabase
    .from("properties")
    .select("id, address_line1, city, state")
    .eq("id", project.property_id)
    .maybeSingle();

  const { data: inspections } = await supabase
    .from("inspections")
    .select("id, name, status, inspection_date, created_at")
    .eq("project_id", id)
    .order("created_at", { ascending: false });

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link
          href={`/properties/${project.property_id}`}
          className="text-sm text-[var(--muted)]"
        >
          ← {property?.address_line1 ?? "Property"}
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              {project.name}
            </h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              {property
                ? [property.address_line1, property.city, property.state]
                    .filter(Boolean)
                    .join(", ")
                : "Property unavailable"}
            </p>
          </div>
          <span className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-medium">
            {project.status}
          </span>
        </div>
      </header>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[0.8fr_1.5fr]">
        <section className="rounded-xl border border-[var(--border)] bg-white p-6">
          <h2 className="font-semibold">Project details</h2>
          <dl className="mt-5 space-y-4 text-sm">
            <Detail label="Status" value={project.status} />
            <Detail label="Start" value={project.start_date || "—"} />
            <Detail
              label="Target completion"
              value={project.target_completion_date || "—"}
            />
            <Detail label="Description" value={project.description || "—"} />
          </dl>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-6 py-5">
            <div>
              <h2 className="font-semibold">Inspections</h2>
              <p className="mt-1 text-xs text-[var(--muted)]">
                Assess the property and record issues before scoping work.
              </p>
            </div>
            <Link
              href={`/projects/${project.id}/inspections/new`}
              className="rounded-lg bg-black px-3.5 py-2 text-sm font-medium text-white"
            >
              New inspection
            </Link>
          </div>

          {inspections?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {inspections.map((inspection) => (
                <Link
                  key={inspection.id}
                  href={`/projects/${project.id}/inspections/${inspection.id}`}
                  className="block px-6 py-5 hover:bg-black/[0.02]"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="font-medium">{inspection.name}</div>
                      <div className="mt-1 text-xs text-[var(--muted)]">
                        {inspection.inspection_date || "Date not set"}
                      </div>
                    </div>
                    <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs font-medium">
                      {inspection.status}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">
              No inspections yet. Start the first inspection to identify
              renovation issues.
            </div>
          )}
        </section>
      </div>
    <div className="px-5 pb-8 md:px-8"><Link href="/projects/<built-in function id>/budget" className="text-sm font-medium underline">Open budget</Link></div><div className="px-5 pb-8 md:px-8"><a href={`/projects/${id}/work-orders`} className="text-sm font-medium underline">Open work orders</a></div><Link href={`/projects/${id}/qc`} className="rounded-lg border border-[var(--border)] px-3 py-2 text-sm">QC</Link></main>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-[var(--muted)]">
        {label}
      </dt>
      <dd className="mt-1">{value}</dd>
    </div>
  );
}
