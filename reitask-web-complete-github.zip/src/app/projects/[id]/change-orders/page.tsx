import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ChangeOrdersPage({params}:{params:Promise<{id:string}>}) {
  const {id}=await params; const supabase=await createClient();
  const [{data:project},{data:orders}]=await Promise.all([
    supabase.from("projects").select("id,name").eq("id",id).maybeSingle(),
    supabase.from("change_orders").select("id,description,reason,cost_impact,schedule_impact_days,status,requested_by,approved_by,approved_at,created_at").eq("project_id",id).order("created_at",{ascending:false})
  ]);
  if(!project) notFound();
  return <main className="min-h-screen bg-[var(--background)]">
    <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
      <Link href={`/projects/${id}`} className="text-sm text-[var(--muted)]">← {project.name}</Link>
      <div className="mt-2 flex flex-wrap items-start justify-between gap-4"><div><h1 className="text-2xl font-semibold tracking-tight">Change Orders</h1><p className="mt-1 text-sm text-[var(--muted)]">Track requested cost and schedule changes without overwriting original scope.</p></div>
      <Link href={`/projects/${id}/change-orders/new`} className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">New change order</Link></div>
    </header>
    <div className="p-5 md:p-8"><section className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">
      {orders?.length ? <div className="divide-y divide-[var(--border)]">{orders.map(o=><Link key={o.id} href={`/projects/${id}/change-orders/${o.id}`} className="block px-5 py-5 hover:bg-black/[0.02]">
        <div className="flex flex-wrap justify-between gap-3"><div className="font-semibold">{o.description}</div><span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">{o.status}</span></div>
        <div className="mt-2 text-sm text-[var(--muted)]">Cost impact: {Number(o.cost_impact).toLocaleString()} · Schedule impact: {o.schedule_impact_days} day(s)</div>
        {o.reason && <div className="mt-1 text-xs text-[var(--muted)]">{o.reason}</div>}
      </Link>)}</div> : <div className="p-8 text-center text-sm text-[var(--muted)]">No change orders yet.</div>}
    </section></div>
  </main>;
}
