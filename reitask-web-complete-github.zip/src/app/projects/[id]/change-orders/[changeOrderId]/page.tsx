import Link from "next/link";
import {notFound} from "next/navigation";
import {createClient} from "@/lib/supabase/server";

const statuses=["DRAFT","SUBMITTED","APPROVED","REJECTED","CANCELLED"];

export default async function ChangeOrderDetail({params}:{params:Promise<{id:string;changeOrderId:string}>}) {
  const {id,changeOrderId}=await params; const supabase=await createClient();
  const {data:order}=await supabase.from("change_orders").select("id,project_id,description,reason,cost_impact,schedule_impact_days,status,requested_by,approved_by,approved_at,created_at").eq("id",changeOrderId).eq("project_id",id).maybeSingle();
  if(!order) notFound();
  return <main className="min-h-screen bg-[var(--background)]"><header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8"><Link href={`/projects/${id}/change-orders`} className="text-sm text-[var(--muted)]">← Change Orders</Link><div className="mt-2 flex justify-between gap-4"><div><h1 className="text-2xl font-semibold">Change order</h1><p className="mt-1 text-sm text-[var(--muted)]">{order.description}</p></div><span className="rounded-full bg-black/5 px-3 py-1.5 text-xs">{order.status}</span></div></header>
  <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[1.3fr_.8fr]"><section className="rounded-xl border border-[var(--border)] bg-white p-5"><h2 className="font-semibold">Request</h2><p className="mt-4 whitespace-pre-wrap text-sm leading-6">{order.description}</p><p className="mt-3 text-sm text-[var(--muted)]">{order.reason||"No reason provided."}</p><div className="mt-5 grid gap-4 border-t pt-5 sm:grid-cols-2"><div>Cost impact: <b>{Number(order.cost_impact).toLocaleString()}</b></div><div>Schedule impact: <b>{order.schedule_impact_days} day(s)</b></div></div></section>
  <section className="rounded-xl border border-[var(--border)] bg-white p-5"><h2 className="font-semibold">Review</h2><form action="/api/change-orders/status" method="post" className="mt-4 space-y-3"><input type="hidden" name="project_id" value={id}/><input type="hidden" name="change_order_id" value={changeOrderId}/><select name="status" defaultValue={order.status} className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5">{statuses.map(x=><option key={x}>{x}</option>)}</select><button className="w-full rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Save decision</button></form></section></div></main>;
}
