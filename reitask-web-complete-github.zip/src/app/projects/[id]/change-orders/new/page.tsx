import Link from "next/link";
import {notFound} from "next/navigation";
import {createClient} from "@/lib/supabase/server";

export default async function NewChangeOrder({params}:{params:Promise<{id:string}>}) {
  const {id}=await params; const supabase=await createClient();
  const {data:project}=await supabase.from("projects").select("id,name").eq("id",id).maybeSingle();
  if(!project) notFound();
  return <main className="min-h-screen bg-[var(--background)]">
    <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8"><Link href={`/projects/${id}/change-orders`} className="text-sm text-[var(--muted)]">← Change Orders</Link><h1 className="mt-2 text-2xl font-semibold">New change order</h1><p className="mt-1 text-sm text-[var(--muted)]">{project.name}</p></header>
    <div className="p-5 md:p-8"><form action="/api/change-orders" method="post" className="max-w-2xl space-y-5 rounded-xl border border-[var(--border)] bg-white p-6">
      <input type="hidden" name="project_id" value={id}/>
      <textarea name="description" required rows={5} placeholder="Describe the requested change" className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"/>
      <textarea name="reason" rows={4} placeholder="Reason" className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"/>
      <div className="grid gap-4 md:grid-cols-2"><input name="cost_impact" type="number" min="0" step="0.01" placeholder="Cost impact" className="rounded-lg border border-[var(--border)] px-3 py-2.5"/><input name="schedule_impact_days" type="number" min="0" step="1" placeholder="Schedule impact (days)" className="rounded-lg border border-[var(--border)] px-3 py-2.5"/></div>
      <div className="rounded-lg bg-black/[0.03] p-4 text-xs text-[var(--muted)]">This request remains separate from the original scope until explicitly approved.</div>
      <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5"><Link href={`/projects/${id}/change-orders`} className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm">Cancel</Link><button className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Submit request</button></div>
    </form></div>
  </main>;
}
