import Link from "next/link";

const metrics = [
  ["Active Projects", "12"],
  ["In Progress", "8"],
  ["Awaiting QC", "3"],
  ["Punch List", "17"]
];

const projects = [
  ["142 Oak Street", "In Progress", "68%", "Electrical"],
  ["88 River Road", "QC", "91%", "Plumbing"],
  ["19 Maple Avenue", "Scoping", "34%", "General"]
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="flex min-h-screen">
        <aside className="hidden w-64 shrink-0 flex-col bg-[var(--sidebar)] text-white md:flex">
          <div className="border-b border-white/10 px-6 py-6">
            <div className="text-xl font-semibold tracking-tight">ReiTask</div>
            <div className="mt-1 text-xs text-[var(--sidebar-muted)]">
              Renovation operations
            </div>
          </div>

          <nav className="flex-1 px-3 py-5">
            <NavItem href="/" label="Dashboard" active />
            <NavItem href="/properties" label="Properties" />
            <NavItem href="#" label="Projects" />
            <NavItem href="#" label="Inspections" />
            <NavItem href="#" label="Scope" />
            <NavItem href="#" label="Work Orders" />
            <NavItem href="#" label="Contractors" />
            <NavItem href="#" label="QC & Punch List" />
          <a href="/contractors" className="text-sm">Contractors</a></nav>

          <div className="border-t border-white/10 px-5 py-5">
            <div className="text-sm font-medium">Organization</div>
            <div className="mt-1 text-xs text-[var(--sidebar-muted)]">
              Operations workspace
            </div>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex h-16 items-center justify-between border-b border-[var(--border)] bg-white px-5 md:px-8">
            <div>
              <div className="text-sm text-[var(--muted)]">Operations</div>
              <h1 className="text-lg font-semibold">Dashboard</h1>
            </div>
            <div className="flex items-center gap-3">
              <button className="rounded-lg border border-[var(--border)] px-3 py-2 text-sm">
                Notifications
              </button>
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-black text-sm font-semibold text-white">
                O
              </div>
            </div>
          </header>

          <div className="p-5 md:p-8">
            <div className="mb-8">
              <p className="text-sm text-[var(--muted)]">Good morning</p>
              <h2 className="mt-1 text-2xl font-semibold tracking-tight">
                Operations control center
              </h2>
              <p className="mt-2 max-w-2xl text-sm text-[var(--muted)]">
                Track renovation work from inspection through completion.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {metrics.map(([label, value]) => (
                <div
                  key={label}
                  className="rounded-xl border border-[var(--border)] bg-white p-5"
                >
                  <div className="text-sm text-[var(--muted)]">{label}</div>
                  <div className="mt-3 text-3xl font-semibold">{value}</div>
                </div>
              ))}
            </div>

            <div className="mt-8 rounded-xl border border-[var(--border)] bg-white">
              <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
                <div>
                  <h3 className="font-semibold">Active project pipeline</h3>
                  <p className="mt-1 text-xs text-[var(--muted)]">
                    Current operational work requiring attention
                  </p>
                </div>
                <Link
                  href="#"
                  className="text-sm font-medium underline underline-offset-4"
                >
                  View all
                </Link>
              </div>

              <div className="divide-y divide-[var(--border)]">
                {projects.map(([address, status, progress, trade]) => (
                  <div
                    key={address}
                    className="grid gap-4 px-5 py-5 md:grid-cols-[1.5fr_1fr_1fr_1fr] md:items-center"
                  >
                    <div>
                      <div className="font-medium">{address}</div>
                      <div className="mt-1 text-xs text-[var(--muted)]">
                        Residential renovation
                      </div>
                    </div>
                    <div>
                      <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs font-medium">
                        {status}
                      </span>
                    </div>
                    <div>
                      <div className="mb-1 flex justify-between text-xs">
                        <span className="text-[var(--muted)]">Progress</span>
                        <span>{progress}</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full bg-black/10">
                        <div
                          className="h-full rounded-full bg-black"
                          style={{ width: progress }}
                        />
                      </div>
                    </div>
                    <div className="text-sm text-[var(--muted)]">{trade}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function NavItem({
  href,
  label,
  active = false
}: {
  href: string;
  label: string;
  active?: boolean;
}) {
  return (
    <Link
      href={href}
      className={`mb-1 block rounded-lg px-3 py-2.5 text-sm ${
        active
          ? "bg-white/10 font-medium text-white"
          : "text-[var(--sidebar-muted)] hover:bg-white/5 hover:text-white"
      }`}
    >
      {label}
    </Link>
  );
}
