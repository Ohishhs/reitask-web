import Link from "next/link";

export default function NewPropertyPage() {
  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href="/properties" className="text-sm text-[var(--muted)]">
          ← Properties
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">
          Add property
        </h1>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Create the property record that projects will attach to.
        </p>
      </div>

      <div className="p-5 md:p-8">
        <form
          action="/api/properties"
          method="post"
          className="max-w-2xl space-y-6 rounded-xl border border-[var(--border)] bg-white p-6"
        >
          <Field name="address_line1" label="Address" required />
          <div className="grid gap-4 md:grid-cols-2">
            <Field name="city" label="City" required />
            <Field name="state" label="State / Region" />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Field name="postal_code" label="Postal code" />
            <div>
              <label className="mb-1.5 block text-sm font-medium">
                Property type
              </label>
              <select
                name="property_type"
                defaultValue="RESIDENTIAL"
                className="w-full rounded-lg border border-[var(--border)] bg-white px-3 py-2.5"
              >
                <option value="RESIDENTIAL">Residential</option>
                <option value="COMMERCIAL">Commercial</option>
                <option value="MULTI_FAMILY">Multi-family</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link
              href="/properties"
              className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium"
            >
              Cancel
            </Link>
            <button
              type="submit"
              className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
            >
              Create property
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}

function Field({
  name,
  label,
  required = false
}: {
  name: string;
  label: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-1.5 block text-sm font-medium">
        {label}
      </label>
      <input
        id={name}
        name={name}
        required={required}
        className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 outline-none focus:border-black"
      />
    </div>
  );
}
