import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function PropertyPage({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const { data: property, error } = await supabase
    .from("properties")
    .select(
      "id, address_line1, city, state, postal_code, status, property_type, notes"
    )
    .eq("id", id)
    .maybeSingle();

  if (error || !property) notFound();

  const { data: projects } = await supabase
    .from("projects")
    .select("id, name, status, start_date, target_completion_date")
    .eq("property_id", id)
    .order("created_at", { ascending: false });

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href="/properties" className="text-sm text-[var(--muted)]">
          ← Properties
        </Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              {property.address_line1}
            </h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              {[property.city, property.state, property.postal_code]
                .filter(Boolean)
                .join(", ")}
            </p>
          </div>
          <span className="rounded-full bg-black/5 px-3 py-1.5 text-xs font-medium">
            {property.status}
          </span>
        </div>
      </div>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-[1fr_1.5fr]">
        <section className="rounded-xl border border-[var(--border)] bg-white p-6">
          <h2 className="font-semibold">Property details</h2>
          <dl className="mt-5 space-y-4 text-sm">
            <Detail label="Type" value={property.property_type} />
            <Detail label="Status" value={property.status} />
            <Detail label="Notes" value={property.notes || "—"} />
          </dl>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-6 py-5">
            <div>
              <h2 className="font-semibold">Projects</h2>
              <p className="mt-1 text-xs text-[var(--muted)]">
                Renovation projects associated with this property.
              </p>
            </div>
            <Link
              href={`/projects/new?property_id=${property.id}`}
              className="rounded-lg bg-black px-3.5 py-2 text-sm font-medium text-white"
            >
              New project
            </Link>
          </div>

          {projects?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {projects.map((project) => (
                <Link
                  key={project.id}
                  href={`/projects/${project.id}`}
                  className="block px-6 py-5 hover:bg-black/[0.02]"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="font-medium">{project.name}</div>
                      <div className="mt-1 text-xs text-[var(--muted)]">
                        {project.start_date || "No start date"} →{" "}
                        {project.target_completion_date || "No target date"}
                      </div>
                    </div>
                    <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs font-medium">
                      {project.status}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">
              No projects yet.
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-wide text-[var(--muted)]">
        {label}
      </dt>
      <dd className="mt-1">{value}</dd>
    </div>
  );
}
