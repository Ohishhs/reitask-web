import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function PropertiesPage() {
  const supabase = await createClient();

  const { data: properties, error } = await supabase
    .from("properties")
    .select("id, address_line1, city, state, postal_code, status, property_type")
    .order("created_at", { ascending: false });

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <div className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <div className="flex items-center justify-between">
          <div>
            <Link href="/" className="text-sm text-[var(--muted)]">
              ← Dashboard
            </Link>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">
              Properties
            </h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Properties owned or managed by your organization.
            </p>
          </div>
          <Link
            href="/properties/new"
            className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
          >
            Add property
          </Link>
        </div>
      </div>

      <div className="p-5 md:p-8">
        {error ? (
          <div className="rounded-xl border border-red-200 bg-red-50 p-5 text-sm text-red-700">
            Unable to load properties. Check your organization membership and
            Supabase configuration.
          </div>
        ) : properties?.length ? (
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">
            <div className="grid grid-cols-[1.5fr_1fr_1fr_1fr] border-b border-[var(--border)] px-5 py-3 text-xs font-medium uppercase tracking-wide text-[var(--muted)]">
              <div>Property</div>
              <div>Type</div>
              <div>Status</div>
              <div>Location</div>
            </div>

            {properties.map((property) => (
              <Link
                key={property.id}
                href={`/properties/${property.id}`}
                className="grid grid-cols-[1.5fr_1fr_1fr_1fr] items-center border-b border-[var(--border)] px-5 py-4 last:border-0 hover:bg-black/[0.02]"
              >
                <div>
                  <div className="font-medium">{property.address_line1}</div>
                  <div className="mt-1 text-xs text-[var(--muted)]">
                    {property.id}
                  </div>
                </div>
                <div className="text-sm">{property.property_type}</div>
                <div>
                  <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs font-medium">
                    {property.status}
                  </span>
                </div>
                <div className="text-sm text-[var(--muted)]">
                  {[property.city, property.state, property.postal_code]
                    .filter(Boolean)
                    .join(", ")}
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-[var(--border)] bg-white p-10 text-center">
            <h2 className="font-semibold">No properties yet</h2>
            <p className="mt-2 text-sm text-[var(--muted)]">
              Add your first property to start a renovation project.
            </p>
            <Link
              href="/properties/new"
              className="mt-5 inline-block rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
            >
              Add property
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}
