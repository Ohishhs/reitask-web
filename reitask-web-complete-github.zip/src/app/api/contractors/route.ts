import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const statuses = new Set(["ACTIVE", "INACTIVE", "SUSPENDED", "ARCHIVED"]);

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const company_name = String(form.get("company_name") ?? "").trim();
  const contact_name = String(form.get("contact_name") ?? "").trim() || null;
  const email = String(form.get("email") ?? "").trim() || null;
  const phone = String(form.get("phone") ?? "").trim() || null;
  const status = String(form.get("status") ?? "ACTIVE");
  const notes = String(form.get("notes") ?? "").trim() || null;

  const { data: membership } = await supabase
    .from("organization_members")
    .select("organization_id")
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .limit(1)
    .maybeSingle();

  if (!membership || !company_name || !statuses.has(status)) {
    return NextResponse.redirect(new URL("/contractors/new?error=not_authorized", request.url));
  }

  const { error } = await supabase.from("contractors").insert({
    organization_id: membership.organization_id,
    company_name, contact_name, email, phone, status, notes
  });

  return NextResponse.redirect(
    new URL(error ? "/contractors/new?error=create_failed" : "/contractors", request.url)
  );
}
