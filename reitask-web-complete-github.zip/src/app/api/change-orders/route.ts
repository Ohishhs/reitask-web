import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";

export async function POST(request:Request){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return NextResponse.redirect(new URL("/login",request.url));
 const f=await request.formData(); const project_id=String(f.get("project_id")??""); const description=String(f.get("description")??"").trim(); const reason=String(f.get("reason")??"").trim()||null; const cost_impact=Number(f.get("cost_impact")??0); const schedule_impact_days=Number(f.get("schedule_impact_days")??0); const back=`/projects/${project_id}/change-orders`;
 const {data:p}=await supabase.from("projects").select("id,organization_id").eq("id",project_id).maybeSingle(); if(!p||!description||!Number.isFinite(cost_impact)||cost_impact<0||!Number.isInteger(schedule_impact_days)||schedule_impact_days<0)return NextResponse.redirect(new URL(`${back}/new?error=invalid`,request.url));
 const {data:m}=await supabase.from("organization_members").select("role").eq("organization_id",p.organization_id).eq("user_id",user.id).eq("status","ACTIVE").in("role",["ADMIN","OPERATIONS_MANAGER","CONTRACTOR"]).maybeSingle();
 if(!m)return NextResponse.redirect(new URL(`${back}?error=not_authorized`,request.url));
 const {error}=await supabase.from("change_orders").insert({organization_id:p.organization_id,project_id,requested_by:user.id,description,reason,cost_impact,schedule_impact_days,status:"DRAFT"});
 return NextResponse.redirect(new URL(error?`${back}/new?error=create_failed`:back,request.url));
}
