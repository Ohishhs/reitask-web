import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
const statuses=new Set(["DRAFT","SUBMITTED","APPROVED","REJECTED","CANCELLED"]);
export async function POST(request:Request){
 const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)return NextResponse.redirect(new URL("/login",request.url));
 const f=await request.formData(); const project_id=String(f.get("project_id")??""); const change_order_id=String(f.get("change_order_id")??""); const status=String(f.get("status")??""); const back=`/projects/${project_id}/change-orders/${change_order_id}`;
 if(!statuses.has(status))return NextResponse.redirect(new URL(`${back}?error=invalid_status`,request.url));
 const {data:o}=await supabase.from("change_orders").select("id,organization_id").eq("id",change_order_id).eq("project_id",project_id).maybeSingle(); if(!o)return NextResponse.redirect(new URL(`${back}?error=not_found`,request.url));
 const {data:m}=await supabase.from("organization_members").select("role").eq("organization_id",o.organization_id).eq("user_id",user.id).eq("status","ACTIVE").in("role",["ADMIN","OPERATIONS_MANAGER"]).maybeSingle(); if(!m)return NextResponse.redirect(new URL(`${back}?error=not_authorized`,request.url));
 const update:any={status,approved_by:null,approved_at:null}; if(status==="APPROVED"){update.approved_by=user.id;update.approved_at=new Date().toISOString();}
 await supabase.from("change_orders").update(update).eq("id",change_order_id);
 return NextResponse.redirect(new URL(back,request.url));
}
