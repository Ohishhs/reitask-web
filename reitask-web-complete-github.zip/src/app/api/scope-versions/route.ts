import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const title = String(form.get("title") ?? "").trim();
  const notes = String(form.get("notes") ?? "").trim() || null;

  const { data: project } = await supabase
    .from("projects")
    .select("id, organization_id")
    .eq("id", project_id)
    .maybeSingle();

  if (!project || !title) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}/scope/new?error=invalid`, request.url)
    );
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", project.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}/scope?error=not_authorized`, request.url)
    );
  }

  const { data: latest } = await supabase
    .from("scope_versions")
    .select("version_number")
    .eq("project_id", project_id)
    .order("version_number", { ascending: false })
    .limit(1)
    .maybeSingle();

  const version_number = (latest?.version_number ?? 0) + 1;

  const { error } = await supabase.from("scope_versions").insert({
    organization_id: project.organization_id,
    project_id,
    version_number,
    title,
    notes,
    status: "DRAFT",
    created_by: user.id
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}/scope/new?error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(
    new URL(`/projects/${project_id}/scope`, request.url)
  );
}
