import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const categories = new Set([
  "MATERIALS",
  "LABOR",
  "PERMITS",
  "EQUIPMENT",
  "SUBCONTRACTOR",
  "OTHER"
]);

function money(value: FormDataEntryValue | null) {
  const raw = String(value ?? "").trim();
  if (!raw) return 0;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const category = String(form.get("category") ?? "");
  const description = String(form.get("description") ?? "").trim();
  const scope_item_id = String(form.get("scope_item_id") ?? "").trim() || null;

  const estimated_amount = money(form.get("estimated_amount"));
  const committed_amount = money(form.get("committed_amount"));
  const actual_amount = money(form.get("actual_amount"));

  const back = `/projects/${project_id}/budget`;

  if (
    !project_id ||
    !categories.has(category) ||
    !description ||
    estimated_amount === null ||
    committed_amount === null ||
    actual_amount === null
  ) {
    return NextResponse.redirect(new URL(`${back}?error=invalid`, request.url));
  }

  const { data: project } = await supabase
    .from("projects")
    .select("id, organization_id")
    .eq("id", project_id)
    .maybeSingle();

  if (!project) {
    return NextResponse.redirect(new URL(`${back}?error=project_not_found`, request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", project.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(new URL(`${back}?error=not_authorized`, request.url));
  }

  if (scope_item_id) {
    const { data: scopeItem } = await supabase
      .from("scope_items")
      .select("id, scope_version_id, scope_versions!inner(project_id)")
      .eq("id", scope_item_id)
      .eq("scope_versions.project_id", project_id)
      .maybeSingle();

    if (!scopeItem) {
      return NextResponse.redirect(new URL(`${back}?error=scope_item_not_found`, request.url));
    }
  }

  const { error } = await supabase.from("budget_items").insert({
    organization_id: project.organization_id,
    project_id,
    scope_item_id,
    category,
    description,
    estimated_amount,
    committed_amount,
    actual_amount
  });

  if (error) {
    return NextResponse.redirect(new URL(`${back}?error=create_failed`, request.url));
  }

  return NextResponse.redirect(new URL(back, request.url));
}
