import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const inspection_id = String(form.get("inspection_id") ?? "");
  const area_id = String(form.get("area_id") ?? "");
  const title = String(form.get("title") ?? "").trim();
  const description =
    String(form.get("description") ?? "").trim() || null;
  const severity = String(form.get("severity") ?? "MEDIUM");
  const trade = String(form.get("trade") ?? "").trim() || null;
  const estimatedRaw = String(form.get("estimated_cost") ?? "").trim();
  const estimated_cost = estimatedRaw ? Number(estimatedRaw) : null;

  const { data: inspection } = await supabase
    .from("inspections")
    .select("id, project_id, organization_id")
    .eq("id", inspection_id)
    .maybeSingle();

  if (!inspection || !area_id || !title) {
    return NextResponse.redirect(new URL("/?error=invalid_issue", request.url));
  }

  const { data: area } = await supabase
    .from("inspection_areas")
    .select("id")
    .eq("id", area_id)
    .eq("inspection_id", inspection_id)
    .maybeSingle();

  if (!area) {
    return NextResponse.redirect(
      new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}?error=invalid_area`, request.url)
    );
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", inspection.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(
      new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}?error=not_authorized`, request.url)
    );
  }

  const { error } = await supabase.from("inspection_issues").insert({
    organization_id: inspection.organization_id,
    inspection_id,
    area_id,
    title,
    description,
    severity,
    status: "OPEN",
    trade,
    estimated_cost: Number.isFinite(estimated_cost) ? estimated_cost : null
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}?error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(
    new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}`, request.url)
  );
}
