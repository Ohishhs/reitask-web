import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const inspection_id = String(form.get("inspection_id") ?? "");
  const name = String(form.get("name") ?? "").trim();

  const { data: inspection } = await supabase
    .from("inspections")
    .select("id, project_id, organization_id")
    .eq("id", inspection_id)
    .maybeSingle();

  if (!inspection || !name) {
    return NextResponse.redirect(new URL("/?error=invalid_area", request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", inspection.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(
      new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}?error=not_authorized`, request.url)
    );
  }

  const { data: latest } = await supabase
    .from("inspection_areas")
    .select("sort_order")
    .eq("inspection_id", inspection_id)
    .order("sort_order", { ascending: false })
    .limit(1)
    .maybeSingle();

  const { error } = await supabase.from("inspection_areas").insert({
    organization_id: inspection.organization_id,
    inspection_id,
    name,
    status: "OPEN",
    sort_order: (latest?.sort_order ?? 0) + 1
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}?error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(
    new URL(`/projects/${inspection.project_id}/inspections/${inspection_id}`, request.url)
  );
}
