import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const priorities = new Set(["LOW","MEDIUM","HIGH","URGENT"]);

function cleanDate(value: FormDataEntryValue | null) {
  const raw = String(value ?? "").trim();
  return raw ? new Date(raw).toISOString() : null;
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const title = String(form.get("title") ?? "").trim();
  const description = String(form.get("description") ?? "").trim() || null;
  const contractor_id = String(form.get("contractor_id") ?? "");
  const priority = String(form.get("priority") ?? "MEDIUM");
  const scope_item_id = String(form.get("scope_item_id") ?? "").trim() || null;

  const { data: project } = await supabase
    .from("projects").select("id, organization_id").eq("id", project_id).maybeSingle();

  if (!project || !title || !contractor_id || !priorities.has(priority)) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/new?error=invalid`, request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", project.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  const { data: assignment } = await supabase
    .from("project_contractors")
    .select("contractor_id")
    .eq("project_id", project_id)
    .eq("contractor_id", contractor_id)
    .eq("organization_id", project.organization_id)
    .eq("status", "ACTIVE")
    .maybeSingle();

  if (!membership || !assignment) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/new?error=not_authorized`, request.url));
  }

  let validScopeItem = null;
  if (scope_item_id) {
    const { data } = await supabase
      .from("scope_items")
      .select("id, scope_versions!inner(project_id)")
      .eq("id", scope_item_id)
      .eq("scope_versions.project_id", project_id)
      .maybeSingle();
    validScopeItem = data;
  }

  const { data: numberRows } = await supabase.rpc("next_work_order_number", { p_project_id: project_id });
  const work_order_number = typeof numberRows === "string" ? numberRows : `WO-${Date.now()}`;

  const { data: order, error } = await supabase
    .from("work_orders")
    .insert({
      organization_id: project.organization_id,
      project_id,
      contractor_id,
      work_order_number,
      title,
      description,
      priority,
      scheduled_start: cleanDate(form.get("scheduled_start")),
      scheduled_end: cleanDate(form.get("scheduled_end")),
      status: "ASSIGNED",
      created_by: user.id
    })
    .select("id")
    .single();

  if (error || !order) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/new?error=create_failed`, request.url));
  }

  if (validScopeItem) {
    await supabase.from("work_order_scope_items").insert({
      work_order_id: order.id,
      scope_item_id: validScopeItem.id,
      organization_id: project.organization_id
    });
  }

  return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/${order.id}`, request.url));
}
