import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const statuses = new Set(["DRAFT","ASSIGNED","ACCEPTED","IN_PROGRESS","SUBMITTED_FOR_REVIEW","QC","COMPLETED","REJECTED","CANCELLED"]);

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const work_order_id = String(form.get("work_order_id") ?? "");
  const status = String(form.get("status") ?? "");

  if (!statuses.has(status)) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/${work_order_id}?error=invalid_status`, request.url));
  }

  const { data: order } = await supabase
    .from("work_orders")
    .select("id, project_id, organization_id, contractor_id")
    .eq("id", work_order_id)
    .eq("project_id", project_id)
    .maybeSingle();

  if (!order) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/${work_order_id}?error=not_found`, request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", order.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .maybeSingle();

  const isManager = membership && ["ADMIN","OPERATIONS_MANAGER"].includes(membership.role);

  if (!isManager) {
    return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/${work_order_id}?error=not_authorized`, request.url));
  }

  await supabase.from("work_orders").update({ status }).eq("id", work_order_id);

  return NextResponse.redirect(new URL(`/projects/${project_id}/work-orders/${work_order_id}`, request.url));
}
