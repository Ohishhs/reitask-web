import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const name = String(form.get("name") ?? "").trim();
  const inspection_date =
    String(form.get("inspection_date") ?? "").trim() || null;
  const summary = String(form.get("summary") ?? "").trim() || null;

  const { data: project } = await supabase
    .from("projects")
    .select("id, organization_id")
    .eq("id", project_id)
    .maybeSingle();

  if (!project || !name) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}/inspections/new?error=invalid`, request.url)
    );
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", project.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}?error=not_authorized`, request.url)
    );
  }

  const { error } = await supabase.from("inspections").insert({
    organization_id: project.organization_id,
    project_id,
    name,
    inspection_date,
    summary,
    status: "DRAFT"
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/${project_id}/inspections/new?error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(new URL(`/projects/${project_id}`, request.url));
}
