import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const work_order_id = String(form.get("work_order_id") ?? "");
  const notes = String(form.get("notes") ?? "").trim() || null;
  const percent = Number(form.get("percent_complete"));

  const back = `/projects/${project_id}/work-orders/${work_order_id}/progress`;

  if (!Number.isFinite(percent) || percent < 0 || percent > 100) {
    return NextResponse.redirect(new URL(`${back}?error=invalid_percent`, request.url));
  }

  const { data: order } = await supabase
    .from("work_orders")
    .select("id, project_id, organization_id, contractor_id, status")
    .eq("id", work_order_id)
    .eq("project_id", project_id)
    .maybeSingle();

  if (!order) return NextResponse.redirect(new URL(`${back}?error=not_found`, request.url));

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", order.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .maybeSingle();

  const manager = membership && ["ADMIN", "OPERATIONS_MANAGER"].includes(membership.role);

  let contractorUser = null;
  if (!manager) {
    const { data } = await supabase
      .from("contractor_users")
      .select("id")
      .eq("contractor_id", order.contractor_id)
      .eq("user_id", user.id)
      .eq("status", "ACTIVE")
      .maybeSingle();
    contractorUser = data;
  }

  if (!manager && !contractorUser) {
    return NextResponse.redirect(new URL(`${back}?error=not_authorized`, request.url));
  }

  const { error } = await supabase.from("progress_updates").insert({
    organization_id: order.organization_id,
    work_order_id: order.id,
    completion_percent: Math.round(percent),
    notes,
    submitted_by: user.id
  });

  if (error) {
    return NextResponse.redirect(new URL(`${back}?error=create_failed`, request.url));
  }

  // Move an assigned/accepted order into active execution when a real progress update is submitted.
  if (percent > 0 && ["ASSIGNED", "ACCEPTED"].includes(order.status)) {
    await supabase.from("work_orders").update({ status: "IN_PROGRESS" }).eq("id", order.id);
  }

  return NextResponse.redirect(new URL(back, request.url));
}
