import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const contractor_id = String(form.get("contractor_id") ?? "");
  const trade_id = String(form.get("trade_id") ?? "");

  const { data: contractor } = await supabase
    .from("contractors")
    .select("id, organization_id")
    .eq("id", contractor_id)
    .maybeSingle();

  const { data: membership } = contractor
    ? await supabase
        .from("organization_members")
        .select("organization_id")
        .eq("organization_id", contractor.organization_id)
        .eq("user_id", user.id)
        .eq("status", "ACTIVE")
        .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
        .maybeSingle()
    : { data: null };

  if (!contractor || !membership || !trade_id) {
    return NextResponse.redirect(new URL(`/contractors/${contractor_id}?error=not_authorized`, request.url));
  }

  await supabase.from("contractor_trades").upsert(
    { contractor_id, trade_id },
    { onConflict: "contractor_id,trade_id" }
  );

  return NextResponse.redirect(new URL(`/contractors/${contractor_id}`, request.url));
}
