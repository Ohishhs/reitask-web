import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const scope_version_id = String(form.get("scope_version_id") ?? "");
  const title = String(form.get("title") ?? "").trim();
  const description =
    String(form.get("description") ?? "").trim() || null;
  const category = String(form.get("category") ?? "").trim() || null;
  const trade = String(form.get("trade") ?? "").trim() || null;
  const unit = String(form.get("unit") ?? "").trim() || null;

  const quantityRaw = String(form.get("quantity") ?? "").trim();
  const estimatedRaw = String(form.get("estimated_cost") ?? "").trim();

  const quantity = quantityRaw ? Number(quantityRaw) : null;
  const estimated_cost = estimatedRaw ? Number(estimatedRaw) : null;

  const { data: version } = await supabase
    .from("scope_versions")
    .select("id, project_id, organization_id, status")
    .eq("id", scope_version_id)
    .maybeSingle();

  if (!version || !title || version.status !== "DRAFT") {
    return NextResponse.redirect(
      new URL(`/projects/${version?.project_id ?? ""}/scope?error=invalid`, request.url)
    );
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", version.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(
      new URL(`/projects/${version.project_id}/scope?error=not_authorized`, request.url)
    );
  }

  const { data: latest } = await supabase
    .from("scope_items")
    .select("sort_order")
    .eq("scope_version_id", scope_version_id)
    .order("sort_order", { ascending: false })
    .limit(1)
    .maybeSingle();

  const { error } = await supabase.from("scope_items").insert({
    organization_id: version.organization_id,
    scope_version_id,
    title,
    description,
    category,
    trade,
    quantity: Number.isFinite(quantity) ? quantity : null,
    unit,
    estimated_cost: Number.isFinite(estimated_cost) ? estimated_cost : null,
    status: "OPEN",
    sort_order: (latest?.sort_order ?? 0) + 1,
    created_by: user.id
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/${version.project_id}/scope?error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(
    new URL(`/projects/${version.project_id}/scope`, request.url)
  );
}
