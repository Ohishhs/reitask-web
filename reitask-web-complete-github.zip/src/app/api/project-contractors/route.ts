import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect(new URL("/login", request.url));

  const form = await request.formData();
  const project_id = String(form.get("project_id") ?? "");
  const contractor_id = String(form.get("contractor_id") ?? "");
  const role = String(form.get("role") ?? "").trim() || null;

  const { data: project } = await supabase
    .from("projects")
    .select("id, organization_id")
    .eq("id", project_id)
    .maybeSingle();

  if (!project) return NextResponse.redirect(new URL(`/projects/${project_id}?error=project_not_found`, request.url));

  const { data: membership } = await supabase
    .from("organization_members")
    .select("role")
    .eq("organization_id", project.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  const { data: contractor } = await supabase
    .from("contractors")
    .select("id")
    .eq("id", contractor_id)
    .eq("organization_id", project.organization_id)
    .maybeSingle();

  if (!membership || !contractor) {
    return NextResponse.redirect(new URL(`/projects/${project_id}?error=not_authorized`, request.url));
  }

  await supabase.from("project_contractors").upsert(
    {
      organization_id: project.organization_id,
      project_id,
      contractor_id,
      role,
      status: "ACTIVE"
    },
    { onConflict: "project_id,contractor_id" }
  );

  return NextResponse.redirect(new URL(`/projects/${project_id}`, request.url));
}
