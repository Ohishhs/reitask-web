import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  const form = await request.formData();
  const address_line1 = String(form.get("address_line1") ?? "").trim();
  const city = String(form.get("city") ?? "").trim();
  const state = String(form.get("state") ?? "").trim() || null;
  const postal_code = String(form.get("postal_code") ?? "").trim() || null;
  const property_type = String(form.get("property_type") ?? "RESIDENTIAL");

  if (!address_line1 || !city) {
    return NextResponse.redirect(new URL("/properties/new?error=missing_fields", request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("organization_id, role")
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .limit(1)
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(new URL("/properties?error=not_authorized", request.url));
  }

  const { error } = await supabase.from("properties").insert({
    organization_id: membership.organization_id,
    address_line1,
    city,
    state,
    postal_code,
    property_type,
    status: "ACTIVE"
  });

  if (error) {
    return NextResponse.redirect(new URL("/properties/new?error=create_failed", request.url));
  }

  return NextResponse.redirect(new URL("/properties", request.url));
}
