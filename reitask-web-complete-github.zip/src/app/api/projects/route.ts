import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  const form = await request.formData();
  const property_id = String(form.get("property_id") ?? "");
  const name = String(form.get("name") ?? "").trim();
  const description = String(form.get("description") ?? "").trim() || null;
  const start_date = String(form.get("start_date") ?? "").trim() || null;
  const target_completion_date =
    String(form.get("target_completion_date") ?? "").trim() || null;

  if (!property_id || !name) {
    return NextResponse.redirect(
      new URL(`/projects/new?property_id=${property_id}&error=missing_fields`, request.url)
    );
  }

  const { data: property } = await supabase
    .from("properties")
    .select("id, organization_id")
    .eq("id", property_id)
    .maybeSingle();

  if (!property) {
    return NextResponse.redirect(new URL("/properties?error=property_not_found", request.url));
  }

  const { data: membership } = await supabase
    .from("organization_members")
    .select("organization_id, role")
    .eq("organization_id", property.organization_id)
    .eq("user_id", user.id)
    .eq("status", "ACTIVE")
    .in("role", ["ADMIN", "OPERATIONS_MANAGER"])
    .maybeSingle();

  if (!membership) {
    return NextResponse.redirect(new URL("/properties?error=not_authorized", request.url));
  }

  const { error } = await supabase.from("projects").insert({
    organization_id: property.organization_id,
    property_id,
    name,
    description,
    start_date,
    target_completion_date,
    status: "PLANNING"
  });

  if (error) {
    return NextResponse.redirect(
      new URL(`/projects/new?property_id=${property_id}&error=create_failed`, request.url)
    );
  }

  return NextResponse.redirect(new URL(`/properties/${property_id}`, request.url));
}
