import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function ContractorDetail({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: contractor }, { data: trades }, { data: assignments }] =
    await Promise.all([
      supabase
        .from("contractors")
        .select("id, company_name, contact_name, email, phone, status, notes")
        .eq("id", id)
        .maybeSingle(),
      supabase
        .from("contractor_trades")
        .select("trade_id, trades(id, name)")
        .eq("contractor_id", id),
      supabase
        .from("project_contractors")
        .select("id, project_id, role, status, assigned_at, projects(id, name)")
        .eq("contractor_id", id)
        .order("assigned_at", { ascending: false })
    ]);

  if (!contractor) notFound();

  const { data: availableTrades } = await supabase
    .from("trades")
    .select("id, name")
    .order("name");

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href="/contractors" className="text-sm text-[var(--muted)]">← Contractors</Link>
        <div className="mt-2 flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">{contractor.company_name}</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">{contractor.contact_name || "No primary contact"}</p>
          </div>
          <span className="rounded-full bg-black/5 px-3 py-1.5 text-xs">{contractor.status}</span>
        </div>
      </header>

      <div className="grid gap-6 p-5 md:p-8 lg:grid-cols-2">
        <section className="rounded-xl border border-[var(--border)] bg-white p-5">
          <h2 className="font-semibold">Contact</h2>
          <div className="mt-4 space-y-2 text-sm">
            <div>Email: {contractor.email || "—"}</div>
            <div>Phone: {contractor.phone || "—"}</div>
            <div className="pt-2 text-[var(--muted)]">{contractor.notes || "No notes."}</div>
          </div>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white p-5">
          <h2 className="font-semibold">Trades</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {trades?.length ? trades.map((row) => (
              <span key={row.trade_id} className="rounded-full bg-black/5 px-3 py-1.5 text-xs">
                {Array.isArray(row.trades) ? row.trades[0]?.name : row.trades?.name}
              </span>
            )) : <span className="text-sm text-[var(--muted)]">No trades assigned.</span>}
          </div>
          <form action="/api/contractor-trades" method="post" className="mt-5 flex gap-2">
            <input type="hidden" name="contractor_id" value={id} />
            <select name="trade_id" required className="min-w-0 flex-1 rounded-lg border border-[var(--border)] px-3 py-2.5">
              <option value="">Select trade</option>
              {availableTrades?.map((trade) => <option key={trade.id} value={trade.id}>{trade.name}</option>)}
            </select>
            <button className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">Add</button>
          </form>
        </section>

        <section className="rounded-xl border border-[var(--border)] bg-white lg:col-span-2">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="font-semibold">Project assignments</h2>
          </div>
          {assignments?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {assignments.map((assignment) => (
                <div key={assignment.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
                  <div>
                    <div className="font-medium">
                      {Array.isArray(assignment.projects) ? assignment.projects[0]?.name : assignment.projects?.name}
                    </div>
                    <div className="mt-1 text-xs text-[var(--muted)]">
                      {assignment.role || "Contractor"} · {assignment.status}
                    </div>
                  </div>
                  <Link href={`/projects/${assignment.project_id}`} className="text-sm underline">Open project</Link>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-6 text-sm text-[var(--muted)]">No project assignments.</div>
          )}
        </section>
      </div>
    </main>
  );
}
