import Link from "next/link";

export default function NewContractorPage() {
  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <Link href="/contractors" className="text-sm text-[var(--muted)]">
          ← Contractors
        </Link>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight">Add contractor</h1>
        <p className="mt-1 text-sm text-[var(--muted)]">
          Create a reusable contractor company record.
        </p>
      </header>

      <div className="p-5 md:p-8">
        <form
          action="/api/contractors"
          method="post"
          className="max-w-2xl space-y-5 rounded-xl border border-[var(--border)] bg-white p-6"
        >
          <div>
            <label className="mb-1.5 block text-sm font-medium">Company name</label>
            <input
              name="company_name"
              required
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5"
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <input name="contact_name" placeholder="Primary contact" className="rounded-lg border border-[var(--border)] px-3 py-2.5" />
            <input name="email" type="email" placeholder="Email" className="rounded-lg border border-[var(--border)] px-3 py-2.5" />
            <input name="phone" placeholder="Phone" className="rounded-lg border border-[var(--border)] px-3 py-2.5" />
            <select name="status" defaultValue="ACTIVE" className="rounded-lg border border-[var(--border)] px-3 py-2.5">
              <option>ACTIVE</option>
              <option>INACTIVE</option>
              <option>SUSPENDED</option>
              <option>ARCHIVED</option>
            </select>
          </div>
          <textarea name="notes" rows={4} placeholder="Notes" className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5" />
          <div className="flex justify-end gap-3 border-t border-[var(--border)] pt-5">
            <Link href="/contractors" className="rounded-lg border border-[var(--border)] px-4 py-2.5 text-sm font-medium">
              Cancel
            </Link>
            <button className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white">
              Create contractor
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}
