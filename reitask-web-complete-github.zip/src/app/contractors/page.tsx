import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function ContractorsPage() {
  const supabase = await createClient();

  const { data: contractors } = await supabase
    .from("contractors")
    .select("id, company_name, contact_name, email, phone, status")
    .order("company_name");

  return (
    <main className="min-h-screen bg-[var(--background)]">
      <header className="border-b border-[var(--border)] bg-white px-5 py-5 md:px-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Contractors</h1>
            <p className="mt-1 text-sm text-[var(--muted)]">
              Reusable contractor companies for project assignments.
            </p>
          </div>
          <Link
            href="/contractors/new"
            className="rounded-lg bg-black px-4 py-2.5 text-sm font-medium text-white"
          >
            Add contractor
          </Link>
        </div>
      </header>

      <div className="p-5 md:p-8">
        <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-white">
          {contractors?.length ? (
            <div className="divide-y divide-[var(--border)]">
              {contractors.map((contractor) => (
                <Link
                  key={contractor.id}
                  href={`/contractors/${contractor.id}`}
                  className="block px-5 py-5 hover:bg-black/[0.02]"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="font-semibold">{contractor.company_name}</div>
                      <div className="mt-1 text-sm text-[var(--muted)]">
                        {contractor.contact_name || "No contact name"} ·{" "}
                        {contractor.email || "No email"} ·{" "}
                        {contractor.phone || "No phone"}
                      </div>
                    </div>
                    <span className="rounded-full bg-black/5 px-2.5 py-1 text-xs">
                      {contractor.status}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-[var(--muted)]">
              No contractors have been added yet.
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
